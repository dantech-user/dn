const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const fmt = number => new Intl.NumberFormat('pt-BR').format(Number(number || 0));
const state = { user: null, farm: null, dashboard: null, animals: [], water: null, drones: [], notifications: [], social: {posts:[],challenges:[],ranking:[]}, route: 'dashboard' };

async function request(url, options = {}) {
  const base = String(window.HYDRA_API_URL || '').replace(/\/$/, '');
  const response = await fetch(base + url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    body: options.body && typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(data.error || 'Ocorreu um erro.'); error.status = response.status; throw error; }
  return data;
}

const icon = id => `<svg aria-hidden="true"><use href="#i-${id}"/></svg>`;
function toast(message, error = false) {
  const el = $('#toast'); el.classList.toggle('error', error); el.querySelector('span').textContent = error ? '!' : '✓'; el.querySelector('p').textContent = message; el.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2800);
}
function buttonLoading(button, loading, text = 'Aguarde...') {
  if (!button.dataset.original) button.dataset.original = button.innerHTML;
  button.disabled = loading; button.innerHTML = loading ? text : button.dataset.original;
}

async function boot() {
  const started = Date.now();
  let me = null;
  try { me = await request('/api/me'); } catch (error) { if (error.status !== 401) toast(error.message, true); }
  const remaining = Math.max(0, 1850 - (Date.now() - started));
  setTimeout(() => {
    $('#splash').classList.add('out');
    if (!me) return showOnly('authView');
    state.user = me.user; state.farm = me.farm;
    if (!me.farm) return showOnly('onboardingView');
    enterApp();
  }, remaining);
}
function showOnly(id) { ['authView','onboardingView','appView'].forEach(view => $(`#${view}`).classList.toggle('hidden', view !== id)); }

$$('[data-auth]').forEach(button => button.addEventListener('click', () => {
  const register = button.dataset.auth === 'register';
  $('#loginPane').classList.toggle('hidden', register); $('#registerPane').classList.toggle('hidden', !register);
}));
$$('.show-pass').forEach(button => button.addEventListener('click', () => {
  const input = button.parentElement.querySelector('input'); input.type = input.type === 'password' ? 'text' : 'password'; button.textContent = input.type === 'password' ? 'Mostrar' : 'Ocultar';
}));

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, button = $('button[type=submit]', form), error = $('.form-error', form); error.textContent = ''; buttonLoading(button, true, 'Entrando...');
  try { await request('/api/auth/login', { method:'POST', body:Object.fromEntries(new FormData(form)) }); const me = await request('/api/me'); state.user=me.user; state.farm=me.farm; me.farm ? enterApp() : showOnly('onboardingView'); }
  catch (e) { error.textContent=e.message; } finally { buttonLoading(button,false); }
});
$('#registerForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form); error.textContent=''; buttonLoading(button,true,'Criando conta...');
  try { await request('/api/auth/register',{method:'POST',body:Object.fromEntries(new FormData(form))}); const me=await request('/api/me');state.user=me.user;showOnly('onboardingView'); }
  catch(e){error.textContent=e.message}finally{buttonLoading(button,false)}
});
$('#farmForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form);error.textContent='';buttonLoading(button,true,'Preparando sua fazenda...');
  try{await request('/api/farm',{method:'POST',body:Object.fromEntries(new FormData(form))});const me=await request('/api/me');state.farm=me.farm;toast('Fazenda configurada com sucesso!');enterApp()}catch(e){error.textContent=e.message}finally{buttonLoading(button,false)}
});

async function enterApp(){showOnly('appView');updateIdentity();await loadCore();route('dashboard')}
function updateIdentity(){const first=state.user.name.split(' ')[0];$('#userName').textContent=first;$('#userInitial').textContent=first[0].toUpperCase();$('#sideFarmName').textContent=state.farm.name;$('#topFarmName').textContent=state.farm.name}
async function loadCore(){
  try{
    [state.dashboard,state.animals,state.water,state.drones,state.notifications,state.social]=await Promise.all([request('/api/dashboard'),request('/api/animals'),request('/api/water'),request('/api/drones'),request('/api/notifications'),request('/api/social')]);
    $('#animalCountBadge').textContent=state.animals.length;const unread=state.notifications.filter(n=>!n.read).length;$('#alertBadge').textContent=unread;
  }catch(e){toast(e.message,true)}
}

function route(name){
  state.route=name;$$('[data-route]').forEach(button=>button.classList.toggle('active',button.dataset.route===name));$('.sidebar').classList.remove('open');$('#drawerBackdrop').classList.remove('show');
  const render={dashboard:renderDashboard,animals:renderAnimals,water:renderWater,drones:renderDrones,community:renderCommunity,challenges:renderChallenges,alerts:renderAlerts,settings:renderSettings}[name]||renderDashboard;render();
}
document.addEventListener('click',event=>{const button=event.target.closest('[data-route]');if(button)route(button.dataset.route);const action=event.target.closest('[data-action]');if(action?.dataset.action==='nfc')openNfc();if(action?.dataset.action==='create')openCreateMenu()});
$('#menuBtn').onclick=()=>{$('.sidebar').classList.add('open');$('#drawerBackdrop').classList.add('show')};
$('#drawerBackdrop').onclick=()=>{$('.sidebar').classList.remove('open');$('#drawerBackdrop').classList.remove('show')};
$('#logoutBtn').onclick=async()=>{await request('/api/auth/logout',{method:'POST'});state.user=null;state.farm=null;showOnly('authView');toast('Sessão encerrada.')};
$('#topNotifications').onclick=()=>route('alerts');

function pageHead(label,title,description,actions=''){return `<div class="page-head"><div><span class="label">${label}</span><h1>${title}</h1><p>${description}</p></div><div class="head-actions">${actions}</div></div>`}
function renderDashboard(){
  const d=state.dashboard,first=esc(state.user.name.split(' ')[0]),low=d.reservoirs.find(r=>r.level<30),percent=Math.min(100,Math.round((d.todayWater/d.waterGoal)*100)),challenge=state.social.challenges[0];
  const hour=new Date().getHours(),greeting=hour<12?'Bom dia':hour<18?'Boa tarde':'Boa noite';
  $('#pageRoot').innerHTML=`<div class="page-enter social-home">
    <div class="mobile-home-head"><div><small>${greeting.toUpperCase()}</small><h1>${first}</h1></div><div class="mobile-head-actions"><button data-route="alerts">${icon('bell')}<i></i></button><button data-route="settings">${first[0]}</button></div></div>
    <div class="farm-stories"><button data-route="animals"><span>${icon('cow')}</span><b>Rebanho</b></button><button data-route="water"><span>${icon('drop')}</span><b>Água</b></button><button data-route="drones"><span>${icon('drone')}</span><b>Drones</b></button><button data-route="challenges"><span>${icon('trophy')}</span><b>Metas</b></button><button data-route="community"><span>${icon('users')}</span><b>Comunidade</b></button></div>
    ${low?`<button class="mobile-alert" data-route="water"><span>${icon('alert')}</span><div><strong>${esc(low.name)} em atenção</strong><small>Nível atual: ${low.level}% da capacidade</small></div><b>›</b></button>`:''}
    <article class="daily-card"><div class="daily-top"><div><span>RESUMO DE HOJE</span><h2>${esc(state.farm.name)}</h2></div><div class="weather-mini">☀ <strong>28°</strong></div></div><div class="daily-progress"><div class="daily-ring" style="--progress:${percent}%"><strong>${percent}%</strong></div><div><span>CONSUMO DE ÁGUA</span><strong>${fmt(d.todayWater)} L</strong><small>de ${fmt(d.waterGoal)} L planejados</small></div></div><div class="daily-stats"><div>${icon('cow')}<span><strong>${d.animalStats.total}</strong><small>animais</small></span></div><div>${icon('drone')}<span><strong>${d.dronesActive}</strong><small>em voo</small></span></div><div>${icon('leaf')}<span><strong>−12%</strong><small>economia</small></span></div></div></article>
    <div class="quick-title"><h2>Acesso rápido</h2><button data-action="create">Ver todos</button></div><div class="quick-grid"><button data-action="nfc"><span>${icon('nfc')}</span><div><strong>Ler NFC</strong><small>Identificar animal</small></div></button><button id="quickWater"><span>${icon('drop')}</span><div><strong>Registrar água</strong><small>Nova leitura</small></div></button><button id="quickAnimal"><span>${icon('cow')}</span><div><strong>Novo animal</strong><small>Adicionar ao rebanho</small></div></button><button data-route="drones"><span>${icon('drone')}</span><div><strong>Nova missão</strong><small>Monitoramento aéreo</small></div></button></div>
    ${challenge?`<div class="quick-title"><h2>Desafio em andamento</h2><button data-route="challenges">Ver todos</button></div><article class="challenge-highlight" data-route="challenges"><span class="challenge-icon">${icon('trophy')}</span><div><strong>${esc(challenge.title)}</strong><small>${challenge.progress} de ${challenge.target} ${esc(challenge.unit)}</small><div><i style="width:${challenge.progress/challenge.target*100}%"></i></div></div><b>${Math.round(challenge.progress/challenge.target*100)}%</b></article>`:''}
    <div class="quick-title"><h2>Atividade da fazenda</h2><button data-route="community">Ver feed</button></div><div class="home-feed">${state.social.posts.slice(0,2).map(postCard).join('')}</div>
  </div>`;
  $('#quickWater').onclick=openWaterForm;$('#quickAnimal').onclick=()=>openAnimalForm();
}
function metric(cls,ico,label,value,caption,progress,change){return `<article class="metric-card ${cls}"><div class="metric-top"><span class="metric-icon">${icon(ico)}</span><b class="metric-change">${change}</b></div><span>${label}</span><strong>${value}</strong><p>${caption}</p><div class="metric-track"><i style="width:${Math.min(100,progress)}%"></i></div></article>`}
function activity(n){const ico=n.type==='animal'?'cow':n.type==='success'?'drop':'alert';return `<li><span class="activity-bubble ${esc(n.type)}">${icon(ico)}</span><div><strong>${esc(n.title)}</strong><small>${esc(n.message)}</small></div><time>${shortDate(n.created_at)}</time></li>`}

function renderAnimals(filter=''){
  const list=state.animals.filter(a=>`${a.name} ${a.tag} ${a.breed} ${a.sector}`.toLowerCase().includes(filter.toLowerCase()));
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('REBANHO','Animais','Identificação, localização e saúde do rebanho.',`<button class="btn outline" data-action="nfc">${icon('nfc')} Ler NFC</button><button class="btn orange" id="addAnimal">${icon('plus')} Novo animal</button>`)}
  <div class="metric-grid"><article class="metric-card animals"><span>Total cadastrado</span><strong>${state.animals.length}</strong><p>animais identificados</p></article><article class="metric-card water"><span>Saudáveis</span><strong>${state.animals.filter(a=>a.status==='Saudável').length}</strong><p>situação normal</p></article><article class="metric-card alerts"><span>Em observação</span><strong>${state.animals.filter(a=>a.status!=='Saudável').length}</strong><p>precisam de atenção</p></article><article class="metric-card drone"><span>Com etiqueta NFC</span><strong>100%</strong><p>do rebanho cadastrado</p></article></div>
  <div class="section-title"><div><span class="label">CADASTROS</span><h2>Todos os animais</h2></div></div><div class="toolbar"><div class="search-box">${icon('search')}<input id="animalSearch" placeholder="Busque por nome, etiqueta ou setor" value="${esc(filter)}"></div></div>
  <article class="panel table-panel"><div class="table-scroll"><table class="data-table"><thead><tr><th>ANIMAL</th><th>SETOR</th><th>PESO</th><th>ÚLTIMA LEITURA</th><th>STATUS</th><th></th></tr></thead><tbody>${list.map(animalRow).join('')}</tbody></table>${list.length?'':'<div class="empty-state">Nenhum animal encontrado.</div>'}</div></article></div>`;
  $('#animalSearch').oninput=e=>renderAnimals(e.target.value);$('#addAnimal').onclick=openAnimalForm;$$('[data-delete-animal]').forEach(b=>b.onclick=()=>deleteAnimal(Number(b.dataset.deleteAnimal)));
}
function animalRow(a){return `<tr><td><div class="animal-cell"><span class="animal-avatar">${icon('cow')}</span><div><strong>${esc(a.name)}</strong><small>${esc(a.tag)} · ${esc(a.species)} ${esc(a.breed)}</small></div></div></td><td>${esc(a.sector)}</td><td>${a.weight?`${fmt(a.weight)} kg`:'—'}</td><td>${shortDate(a.last_seen)}</td><td><span class="status-pill ${a.status==='Saudável'?'':'watch'}">${esc(a.status)}</span></td><td><button class="row-action" data-delete-animal="${a.id}">Excluir</button></td></tr>`}
function openAnimalForm(prefill=''){
  openModal('NOVO CADASTRO','Adicionar animal',`<form id="animalForm" class="modal-form"><label>Etiqueta NFC<input name="tag" value="${esc(prefill)}" placeholder="AG-0001" required></label><label>Nome do animal<input name="name" placeholder="Ex.: Estrela" required></label><label>Espécie<select name="species"><option>Bovino</option><option>Equino</option><option>Ovino</option><option>Caprino</option></select></label><label>Raça<input name="breed" placeholder="Ex.: Nelore"></label><label>Setor<input name="sector" placeholder="Ex.: Pasto Sul" required></label><label>Peso (kg)<input type="number" name="weight" min="0" placeholder="0"></label><label class="full">Situação<select name="status"><option>Saudável</option><option>Observação</option><option>Tratamento</option></select></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Salvar animal</button></form>`);
  $('#animalForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,button=$('button[type=submit]',form);buttonLoading(button,true,'Salvando...');try{await request('/api/animals',{method:'POST',body:Object.fromEntries(new FormData(form))});state.animals=await request('/api/animals');$('#animalCountBadge').textContent=state.animals.length;closeModal();renderAnimals();toast('Animal cadastrado no banco de dados.')}catch(err){$('.form-error',form).textContent=err.message}finally{buttonLoading(button,false)}};
}
async function deleteAnimal(id){if(!confirm('Deseja excluir este animal do cadastro?'))return;try{await request(`/api/animals/${id}`,{method:'DELETE'});state.animals=state.animals.filter(a=>a.id!==id);renderAnimals();toast('Animal removido.')}catch(e){toast(e.message,true)}}

function renderWater(){
  const w=state.water, max=Math.max(...w.history.map(h=>h.liters),1);
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('GESTÃO HÍDRICA','Água','Reservatórios, consumo e metas de economia.',`<button class="btn orange" id="addWater">${icon('plus')} Registrar consumo</button>`)}
  <div class="reservoir-grid">${w.reservoirs.map(r=>`<article class="reservoir-card"><div class="card-top"><div><h3>${esc(r.name)}</h3><p>${esc(r.sector)} · ${fmt(r.capacity)} L</p></div><strong class="level-number ${r.level<30?'low':''}">${r.level}%</strong></div><div class="level-track ${r.level<30?'low':''}"><i style="width:${r.level}%"></i></div><div class="card-foot"><span>Nível atual</span><button class="row-action" data-reservoir="${r.id}" data-level="${r.level}">Atualizar</button></div></article>`).join('')}</div>
  <article class="panel" style="margin-top:14px"><div class="panel-title"><div><span class="label">ÚLTIMOS 7 DIAS</span><h3>Histórico de consumo</h3></div><strong class="green" style="font-size:10px">−12% esta semana</strong></div><div class="chart">${w.history.map(h=>`<div class="chart-col"><strong>${fmt(h.liters)} L</strong><i style="height:${Math.max(12,h.liters/max*86)}%"></i><span>${dayLabel(h.day)}</span></div>`).join('')}</div></article></div>`;
  $('#addWater').onclick=openWaterForm;$$('[data-reservoir]').forEach(b=>b.onclick=()=>updateReservoir(b.dataset.reservoir,b.dataset.level));
}
function openWaterForm(){openModal('NOVA LEITURA','Registrar consumo',`<form id="waterForm" class="modal-form"><label class="full">Setor<input name="sector" placeholder="Ex.: Irrigação do cacau" required></label><label class="full">Quantidade utilizada (litros)<input type="number" name="liters" min="1" placeholder="Ex.: 680" required></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Salvar leitura</button></form>`);$('#waterForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;try{await request('/api/water',{method:'POST',body:Object.fromEntries(new FormData(form))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Consumo registrado no banco de dados.')}catch(err){$('.form-error',form).textContent=err.message}}}
function updateReservoir(id,current){openModal('NÍVEL DO RESERVATÓRIO','Atualizar medição',`<form id="levelForm" class="modal-form"><label class="full">Nível atual: <b id="levelOutput">${current}%</b><input type="range" name="level" min="0" max="100" value="${current}" style="padding:0"></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Atualizar nível</button></form>`);$('[name=level]').oninput=e=>$('#levelOutput').textContent=e.target.value+'%';$('#levelForm').onsubmit=async e=>{e.preventDefault();try{await request(`/api/reservoirs/${id}`,{method:'PATCH',body:Object.fromEntries(new FormData(e.currentTarget))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Reservatório atualizado.')}catch(err){toast(err.message,true)}}}

function renderDrones(){
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('MONITORAMENTO AÉREO','Drones','Inspeções inteligentes em toda a propriedade.',`<button class="btn orange" id="newMission">${icon('plus')} Nova missão</button>`)}<div class="drone-grid">${state.drones.map(d=>`<article class="drone-card"><div class="card-top"><div><h3>${esc(d.name)}</h3><p>${esc(d.model)}</p></div><span class="drone-status ${d.status==='Em voo'?'':'base'}">● ${esc(d.status)}</span></div><div class="drone-visual">${icon('drone')}</div><div class="drone-info"><span>${esc(d.mission)}</span><strong>${d.battery}%</strong></div><div class="level-track"><i style="width:${d.battery}%"></i></div></article>`).join('')}</div><article class="panel" style="margin-top:14px"><div class="panel-title"><div><span class="label">COBERTURA</span><h3>Operações da propriedade</h3></div></div><div class="warning-banner" style="margin:0;background:#edf5ef;border-color:#d7e8db;border-left-color:var(--green)">${icon('drone')}<div><strong>2 missões em andamento</strong><p>Monitoramento do rebanho e inspeção da plantação de cacau.</p></div></div></article></div>`;
  $('#newMission').onclick=()=>toast('Planejador de missão preparado para integração com o drone.');
}
function postCard(post){
  const categoryIcon=post.category.includes('água')?'drop':post.category==='Rebanho'?'cow':'drone';
  return `<article class="social-post"><header><span class="post-avatar">${state.farm.name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase()}</span><div><strong>${esc(state.farm.name)}</strong><small>${esc(state.farm.city)}, ${esc(state.farm.state)} · ${longDate(post.created_at)}</small></div><button>•••</button></header><div class="post-cover ${categoryIcon}"><span>${icon(categoryIcon)}</span><div><small>${esc(post.category).toUpperCase()}</small><strong>${categoryIcon==='drop'?'Cada litro faz diferença.':categoryIcon==='cow'?'Tecnologia cuidando do rebanho.':'O campo visto de cima.'}</strong></div></div><p>${esc(post.content)}</p><footer><button data-like="${post.id}">${icon('heart')} <span>${post.reactions}</span></button><button>${icon('comment')} ${post.comments}</button><b>${esc(post.category)}</b></footer></article>`;
}
function renderCommunity(){
  $('#pageRoot').innerHTML=`<div class="page-enter social-page">${pageHead('REDE HYDRA','Comunidade','Compartilhe resultados e acompanhe a evolução da propriedade.',`<button class="btn orange" id="newPost">${icon('plus')} Publicar</button>`)}<div class="community-tabs"><button class="active">Para você</button><button data-route="challenges">Ranking</button><button data-route="challenges">Desafios</button></div><div class="composer" id="composer"><span>${state.user.name[0].toUpperCase()}</span><button id="composerButton">Compartilhe uma conquista da fazenda...</button>${icon('leaf')}</div><div class="social-feed">${state.social.posts.map(postCard).join('')}</div></div>`;
  $('#newPost').onclick=openPostForm;$('#composerButton').onclick=openPostForm;$$('[data-like]').forEach(button=>button.onclick=()=>{if(button.classList.toggle('liked')){button.querySelector('span').textContent=Number(button.querySelector('span').textContent)+1;toast('Você apoiou esta publicação.')}});
}
function openPostForm(){
  openModal('NOVA PUBLICAÇÃO','Compartilhar no feed',`<form id="postForm" class="modal-form"><label class="full">Categoria<select name="category"><option>Economia de água</option><option>Rebanho</option><option>Tecnologia</option><option>Conquista</option><option>Atualização</option></select></label><label class="full">O que aconteceu?<textarea name="content" maxlength="500" placeholder="Conte uma novidade da sua fazenda..." required></textarea></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Publicar atualização</button></form>`);
  $('#postForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,button=$('button[type=submit]',form);buttonLoading(button,true,'Publicando...');try{await request('/api/posts',{method:'POST',body:Object.fromEntries(new FormData(form))});state.social=await request('/api/social');closeModal();renderCommunity();toast('Atualização publicada no feed.')}catch(err){$('.form-error',form).textContent=err.message}finally{buttonLoading(button,false)}};
}
function renderChallenges(){
  const myRank=state.social.ranking.find(r=>r.mine);
  $('#pageRoot').innerHTML=`<div class="page-enter social-page">${pageHead('PROGRESSO','Desafios','Metas que tornam sua propriedade mais inteligente e sustentável.')}<article class="rank-hero"><span>${icon('trophy')}</span><div><small>SUA POSIÇÃO EM BREJÕES E REGIÃO</small><strong>${myRank?.position||2}º lugar</strong><p>${myRank?.saving||18}% de economia de água neste mês</p></div><button id="showRanking">Ver ranking</button></article><div class="quick-title"><h2>Seus desafios</h2><span>${state.social.challenges.length} ativos</span></div><div class="challenge-list">${state.social.challenges.map(c=>challengeCard(c)).join('')}</div><div class="quick-title"><h2>Ranking sustentável</h2><span>Agosto</span></div><article class="ranking-card">${state.social.ranking.map(r=>`<div class="rank-row ${r.mine?'mine':''}"><b>${r.position}</b><span>${r.name.split(' ').map(p=>p[0]).slice(0,2).join('')}</span><div><strong>${esc(r.name)}</strong><small>${esc(r.city)}</small></div><em>${r.saving}%</em></div>`).join('')}</article></div>`;
  $('#showRanking').onclick=()=>$('.ranking-card').scrollIntoView({behavior:'smooth'});$$('[data-progress]').forEach(button=>button.onclick=()=>updateChallenge(button.dataset.progress,button.dataset.value));
}
function challengeCard(c){const pct=Math.min(100,Math.round(c.progress/c.target*100));return `<article class="challenge-card"><div class="challenge-card-top"><span>${icon(c.title.includes('água')?'drop':c.title.includes('Rebanho')?'cow':'drone')}</span><div><small>DESAFIO ATIVO</small><strong>${esc(c.title)}</strong><p>${esc(c.description)}</p></div><b>${pct}%</b></div><div class="challenge-progress"><i style="width:${pct}%"></i></div><footer><span>${c.progress} de ${c.target} ${esc(c.unit)}</span><button data-progress="${c.id}" data-value="${c.progress+1}" ${pct===100?'disabled':''}>${pct===100?'Concluído':'Registrar +1'}</button></footer></article>`}
async function updateChallenge(id,value){try{await request(`/api/challenges/${id}`,{method:'PATCH',body:{progress:Number(value)}});state.social=await request('/api/social');renderChallenges();toast('Progresso atualizado.')}catch(e){toast(e.message,true)}}
function openCreateMenu(){
  openModal('AÇÃO RÁPIDA','O que deseja fazer?',`<div class="create-menu"><button id="createPost">${settingIcon('leaf')}<div><strong>Nova publicação</strong><small>Compartilhar uma atualização</small></div><b>›</b></button><button id="createAnimal">${settingIcon('cow')}<div><strong>Cadastrar animal</strong><small>Adicionar ao rebanho</small></div><b>›</b></button><button id="createNfc">${settingIcon('nfc')}<div><strong>Ler etiqueta NFC</strong><small>Identificar um animal</small></div><b>›</b></button><button id="createWater">${settingIcon('drop')}<div><strong>Registrar consumo</strong><small>Adicionar leitura de água</small></div><b>›</b></button></div>`);
  $('#createPost').onclick=()=>{closeModal();openPostForm()};$('#createAnimal').onclick=()=>{closeModal();openAnimalForm()};$('#createNfc').onclick=()=>{closeModal();openNfc()};$('#createWater').onclick=()=>{closeModal();openWaterForm()};
}
function renderAlerts(){
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('CENTRAL DE AVISOS','Alertas','Tudo que precisa da sua atenção na fazenda.')}<div class="notice-list">${state.notifications.map(n=>`<article class="notice-card"><span class="notice-icon ${esc(n.type)}">${icon(n.type==='animal'?'cow':n.type==='success'?'drop':'alert')}</span><div><strong>${esc(n.title)}</strong><p>${esc(n.message)}</p><time>${longDate(n.created_at)}</time></div></article>`).join('')}</div></div>`;
}
function renderSettings(){const initials=state.user.name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();$('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('PREFERÊNCIAS','Configurações','Dados da conta e da propriedade.')}<div class="settings-layout"><article class="panel profile-panel"><div class="big-avatar">${esc(initials)}</div><h2>${esc(state.user.name)}</h2><p>${esc(state.user.email)}<br>Administrador da propriedade</p><div class="farm-info"><div><span>Propriedade</span><strong>${esc(state.farm.name)}</strong></div><div><span>Localização</span><strong>${esc(state.farm.city)} · ${esc(state.farm.state)}</strong></div><div><span>Área</span><strong>${fmt(state.farm.area)} ha</strong></div></div></article><div class="settings-list"><button class="setting-card">${settingIcon('home')}<div><strong>Dados da propriedade</strong><small>Nome, localização, área e atividade</small></div><b>›</b></button><button class="setting-card" data-route="water">${settingIcon('drop')}<div><strong>Meta de consumo</strong><small>Objetivo atual: ${fmt(state.farm.water_goal)} litros por dia</small></div><b>›</b></button><button class="setting-card" data-route="alerts">${settingIcon('bell')}<div><strong>Notificações e alertas</strong><small>Água, animais e operações aéreas</small></div><b>›</b></button><button class="setting-card" id="settingsLogout">${settingIcon('logout')}<div><strong>Sair da conta</strong><small>Encerrar a sessão neste dispositivo</small></div><b>›</b></button></div></div></div>`;$('#settingsLogout').onclick=()=>$('#logoutBtn').click()}
function settingIcon(name){return `<span>${icon(name)}</span>`}

function openModal(label,title,body){$('#modalLabel').textContent=label;$('#modalTitle').textContent=title;$('#modalBody').innerHTML=body;$('#appModal').showModal()}
function closeModal(){$('#appModal').close()}$$('[data-close]').forEach(b=>b.onclick=closeModal);$('#appModal').addEventListener('click',e=>{if(e.target===$('#appModal'))closeModal()});
async function openNfc(){
  openModal('IDENTIFICAÇÃO','Leitor NFC',`<div class="nfc-scan"><div class="nfc-rings"><i></i><i></i>${icon('nfc')}</div><h3>Aproxime a etiqueta</h3><p id="nfcStatus">Encoste o celular no brinco NFC do animal.</p><button id="simulateNfc" class="btn soft wide">Simular etiqueta AG-${String(Math.floor(Math.random()*9000)+1000)}</button></div>`);
  $('#simulateNfc').onclick=()=>{const tag=$('#simulateNfc').textContent.match(/AG-\d+/)?.[0]||'AG-0001';closeModal();openAnimalForm(tag)};
  if('NDEFReader' in window){try{const reader=new NDEFReader();await reader.scan();$('#nfcStatus').textContent='Leitor ativo. Aproxime a etiqueta NFC.';reader.onreading=event=>{let tag=event.serialNumber||'';for(const record of event.message.records){if(record.recordType==='text')tag=new TextDecoder(record.encoding||'utf-8').decode(record.data)}closeModal();openAnimalForm(tag||'NFC-LIDO')}}catch(e){$('#nfcStatus').textContent='Permissão NFC não concedida. Use a simulação abaixo.'}}
}
function shortDate(value){const date=new Date(String(value).replace(' ','T')+'Z');return new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(date)}
function longDate(value){const date=new Date(String(value).replace(' ','T')+'Z');return new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}).format(date)}
function dayLabel(value){const date=new Date(value+'T12:00:00');return new Intl.DateTimeFormat('pt-BR',{weekday:'short'}).format(date).replace('.','')}
boot();
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
