-- Hydra Agro - banco de produção (Supabase/PostgreSQL)
-- Execute este arquivo uma única vez no SQL Editor do projeto Supabase.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.farms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  city text not null,
  state text not null,
  area numeric not null default 0,
  activity text not null default 'Pecuária e agricultura',
  water_goal integer not null default 3500,
  created_at timestamptz not null default now()
);

create table if not exists public.animals (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  tag text not null,
  name text not null,
  species text not null default 'Bovino',
  breed text not null default '',
  sector text not null,
  status text not null default 'Saudável',
  weight numeric not null default 0,
  last_seen timestamptz not null default now(),
  unique(farm_id, tag)
);

create table if not exists public.reservoirs (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  sector text not null,
  capacity integer not null,
  level integer not null check(level between 0 and 100),
  updated_at timestamptz not null default now()
);

create table if not exists public.water_logs (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  sector text not null,
  liters integer not null check(liters > 0),
  recorded_at timestamptz not null default now()
);

create table if not exists public.drones (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  model text not null,
  status text not null default 'Na base',
  battery integer not null default 100 check(battery between 0 and 100),
  mission text not null default 'Disponível'
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  category text not null default 'Atualização',
  content text not null check(char_length(content) between 3 and 500),
  image_url text,
  reactions integer not null default 0,
  comments integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  title text not null,
  description text not null,
  target integer not null,
  progress integer not null default 0,
  unit text not null,
  ends_at date not null,
  joined boolean not null default true
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  type text not null,
  title text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists farms_owner_idx on public.farms(owner_id);
create index if not exists animals_farm_idx on public.animals(farm_id);
create index if not exists water_logs_farm_date_idx on public.water_logs(farm_id, recorded_at desc);
create index if not exists posts_farm_date_idx on public.posts(farm_id, created_at desc);

create or replace function public.owns_farm(target_farm uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.farms where id = target_farm and owner_id = (select auth.uid())) $$;

alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.animals enable row level security;
alter table public.reservoirs enable row level security;
alter table public.water_logs enable row level security;
alter table public.drones enable row level security;
alter table public.posts enable row level security;
alter table public.challenges enable row level security;
alter table public.notifications enable row level security;

create policy "profile owner access" on public.profiles for all to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "farm owner access" on public.farms for all to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "animal farm owner access" on public.animals for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "reservoir farm owner access" on public.reservoirs for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "water farm owner access" on public.water_logs for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "drone farm owner access" on public.drones for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "post owner write" on public.posts for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "post community read" on public.posts for select to authenticated using (true);
create policy "challenge farm owner access" on public.challenges for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));
create policy "notification farm owner access" on public.notifications for all to authenticated using ((select public.owns_farm(farm_id))) with check ((select public.owns_farm(farm_id)));

grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant execute on function public.owns_farm(uuid) to authenticated;

insert into storage.buckets (id, name, public)
values ('farm-media', 'farm-media', true)
on conflict (id) do nothing;

create policy "farm media authenticated upload" on storage.objects for insert to authenticated with check (bucket_id = 'farm-media');
create policy "farm media public read" on storage.objects for select to public using (bucket_id = 'farm-media');
create policy "farm media owner delete" on storage.objects for delete to authenticated using (bucket_id = 'farm-media' and owner_id = (select auth.uid()::text));
