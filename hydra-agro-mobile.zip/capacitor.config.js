const config = {
  appId: 'com.hydraagro.app',
  appName: 'Hydra Agro',
  webDir: 'public',
  backgroundColor: '#174c36',
  android: { backgroundColor: '#174c36', allowMixedContent: false }
};

if (process.env.HYDRA_APP_URL) {
  config.server = { url: process.env.HYDRA_APP_URL, cleartext: false, androidScheme: 'https' };
}

module.exports = config;
