const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 4173);
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'hydra-agro.sqlite'));
db.exec(`
  PRAGMA foreign_keys = ON;
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS farms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    area REAL NOT NULL DEFAULT 0,
    activity TEXT NOT NULL DEFAULT 'Pecuária e agricultura',
    water_goal INTEGER NOT NULL DEFAULT 3500,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS animals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    name TEXT NOT NULL,
    species TEXT NOT NULL,
    breed TEXT NOT NULL DEFAULT '',
    sector TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Saudável',
    weight REAL NOT NULL DEFAULT 0,
    last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(farm_id, tag)
  );
  CREATE TABLE IF NOT EXISTS reservoirs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    sector TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    level INTEGER NOT NULL CHECK(level BETWEEN 0 AND 100),
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS water_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    sector TEXT NOT NULL,
    liters INTEGER NOT NULL,
    recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS drones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    model TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Na base',
    battery INTEGER NOT NULL DEFAULT 100,
    mission TEXT NOT NULL DEFAULT 'Disponível'
  );
  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    category TEXT NOT NULL DEFAULT 'Atualização',
    content TEXT NOT NULL,
    reactions INTEGER NOT NULL DEFAULT 0,
    comments INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    target INTEGER NOT NULL,
    progress INTEGER NOT NULL DEFAULT 0,
    unit TEXT NOT NULL,
    ends_at TEXT NOT NULL,
    joined INTEGER NOT NULL DEFAULT 1
  );
`);

const json = (res, status, body) => {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(body));
};

const readBody = req => new Promise((resolve, reject) => {
  let raw = '';
  req.on('data', chunk => {
    raw += chunk;
    if (raw.length > 1_000_000) reject(new Error('Payload muito grande'));
  });
  req.on('end', () => {
    try { resolve(raw ? JSON.parse(raw) : {}); }
    catch { reject(new Error('JSON inválido')); }
  });
});

const clean = (value, max = 120) => String(value ?? '').trim().slice(0, max);
const passwordHash = password => {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
};
const passwordMatches = (password, stored) => {
  const [salt, key] = stored.split(':');
  if (!salt || !key) return false;
  const calculated = crypto.scryptSync(password, Buffer.from(salt, 'hex'), 64);
  return crypto.timingSafeEqual(calculated, Buffer.from(key, 'hex'));
};
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').filter(Boolean).map(v => {
  const [key, ...rest] = v.trim().split('=');
  return [key, decodeURIComponent(rest.join('='))];
}));
const createSession = (res, userId) => {
  const token = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const expires = new Date(Date.now() + 30 * 864e5).toISOString();
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(tokenHash, userId, expires);
  res.setHeader('Set-Cookie', `hydra_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`);
};
const auth = req => {
  const token = cookies(req).hydra_session;
  if (!token) return null;
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const row = db.prepare(`SELECT u.id,u.name,u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>datetime('now')`).get(hash);
  return row || null;
};
const farmFor = userId => db.prepare('SELECT * FROM farms WHERE user_id=?').get(userId);

function seedFarm(farmId) {
  const animals = [
    ['AG-0842','Estrela','Bovino','Nelore','Pasto Sul','Saudável',487],
    ['AG-0839','Trovão','Bovino','Nelore','Pasto Norte','Saudável',553],
    ['AG-0811','Jade','Bovino','Girolando','Curral 02','Observação',421],
    ['AG-0784','Pérola','Bovino','Nelore','Pasto Leste','Saudável',469],
    ['AG-0765','Valente','Bovino','Angus','Pasto Sul','Saudável',581]
  ];
  const insertAnimal = db.prepare('INSERT INTO animals(farm_id,tag,name,species,breed,sector,status,weight) VALUES(?,?,?,?,?,?,?,?)');
  animals.forEach(a => insertAnimal.run(farmId, ...a));
  const reservoirs = [['Reservatório Central','Sede',20000,78],['Reservatório Norte','Pasto Norte',15000,27],['Reservatório Leste','Cacau',15000,64]];
  const insertReservoir = db.prepare('INSERT INTO reservoirs(farm_id,name,sector,capacity,level) VALUES(?,?,?,?,?)');
  reservoirs.forEach(r => insertReservoir.run(farmId, ...r));
  const insertLog = db.prepare("INSERT INTO water_logs(farm_id,sector,liters,recorded_at) VALUES(?,?,?,datetime('now',?))");
  [2840,2710,2590,2920,2680,2530,2480].forEach((liters, i) => insertLog.run(farmId, 'Toda a fazenda', liters, `-${6-i} days`));
  const insertDrone = db.prepare('INSERT INTO drones(farm_id,name,model,status,battery,mission) VALUES(?,?,?,?,?,?)');
  [['Drone 01','DJI Agras','Em voo',82,'Mapeamento do Pasto Sul'],['Drone 02','DJI Mavic 3M','Em voo',61,'Inspeção do cacau'],['Drone 03','DJI Mini','Na base',100,'Disponível']].forEach(d => insertDrone.run(farmId, ...d));
  const insertNotice = db.prepare('INSERT INTO notifications(farm_id,type,title,message) VALUES(?,?,?,?)');
  [['warning','Nível de água baixo','O Reservatório Norte está com apenas 27%.'],['animal','Animal em observação','Jade · AG-0811 precisa de acompanhamento.'],['success','Meta de economia','O consumo caiu 12% nos últimos 7 dias.']].forEach(n => insertNotice.run(farmId, ...n));
  const insertPost = db.prepare("INSERT INTO posts(farm_id,category,content,reactions,comments,created_at) VALUES(?,?,?,?,?,datetime('now',?))");
  [
    ['Economia de água','Reduzimos o consumo da irrigação em 12% nesta semana. Cada litro conta!',28,4,'-2 hours'],
    ['Rebanho','Estrela recebeu uma nova etiqueta NFC e já está sendo monitorada pelo Hydra Agro.',19,2,'-1 day'],
    ['Tecnologia','Inspeção aérea concluída no talhão de cacau. Nenhuma área crítica encontrada.',34,6,'-2 days']
  ].forEach(p => insertPost.run(farmId, ...p));
  const insertChallenge = db.prepare("INSERT INTO challenges(farm_id,title,description,target,progress,unit,ends_at) VALUES(?,?,?,?,?,?,date('now',?))");
  [
    ['7 dias economizando água','Mantenha o consumo abaixo da meta durante uma semana.',7,5,'dias','+2 days'],
    ['Rebanho 100% identificado','Cadastre etiquetas NFC em todos os animais da propriedade.',127,124,'animais','+14 days'],
    ['Fazenda monitorada','Complete dez inspeções com drone.',10,6,'missões','+21 days']
  ].forEach(c => insertChallenge.run(farmId, ...c));
}

function ensureSocial(farmId) {
  if (!db.prepare('SELECT id FROM posts WHERE farm_id=? LIMIT 1').get(farmId)) {
    const insertPost = db.prepare("INSERT INTO posts(farm_id,category,content,reactions,comments,created_at) VALUES(?,?,?,?,?,datetime('now',?))");
    [['Economia de água','Reduzimos o consumo da irrigação em 12% nesta semana. Cada litro conta!',28,4,'-2 hours'],['Rebanho','Estrela recebeu uma nova etiqueta NFC e já está sendo monitorada pelo Hydra Agro.',19,2,'-1 day'],['Tecnologia','Inspeção aérea concluída no talhão de cacau. Nenhuma área crítica encontrada.',34,6,'-2 days']].forEach(p => insertPost.run(farmId, ...p));
  }
  if (!db.prepare('SELECT id FROM challenges WHERE farm_id=? LIMIT 1').get(farmId)) {
    const insertChallenge = db.prepare("INSERT INTO challenges(farm_id,title,description,target,progress,unit,ends_at) VALUES(?,?,?,?,?,?,date('now',?))");
    [['7 dias economizando água','Mantenha o consumo abaixo da meta durante uma semana.',7,5,'dias','+2 days'],['Rebanho 100% identificado','Cadastre etiquetas NFC em todos os animais da propriedade.',127,124,'animais','+14 days'],['Fazenda monitorada','Complete dez inspeções com drone.',10,6,'missões','+21 days']].forEach(c => insertChallenge.run(farmId, ...c));
  }
}

function dashboard(farm) {
  const today = db.prepare("SELECT COALESCE(SUM(liters),0) total FROM water_logs WHERE farm_id=? AND date(recorded_at)=date('now')").get(farm.id).total;
  const animalStats = db.prepare("SELECT COUNT(*) total,SUM(CASE WHEN status='Saudável' THEN 1 ELSE 0 END) healthy,SUM(CASE WHEN status!='Saudável' THEN 1 ELSE 0 END) attention FROM animals WHERE farm_id=?").get(farm.id);
  const dronesActive = db.prepare("SELECT COUNT(*) total FROM drones WHERE farm_id=? AND status='Em voo'").get(farm.id).total;
  const reservoirs = db.prepare('SELECT * FROM reservoirs WHERE farm_id=? ORDER BY level ASC').all(farm.id);
  const history = db.prepare("SELECT date(recorded_at) day,SUM(liters) liters FROM water_logs WHERE farm_id=? AND recorded_at>=date('now','-6 days') GROUP BY date(recorded_at) ORDER BY day").all(farm.id);
  const notifications = db.prepare('SELECT * FROM notifications WHERE farm_id=? ORDER BY created_at DESC LIMIT 5').all(farm.id);
  return { todayWater: today, animalStats, dronesActive, reservoirs, history, notifications, waterGoal: farm.water_goal };
}

async function api(req, res, pathname) {
  try {
    if (pathname === '/api/auth/register' && req.method === 'POST') {
      const body = await readBody(req);
      const name = clean(body.name, 80), email = clean(body.email, 150).toLowerCase(), password = String(body.password || '');
      if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 6) return json(res, 400, { error: 'Preencha nome, e-mail válido e senha com no mínimo 6 caracteres.' });
      if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return json(res, 409, { error: 'Este e-mail já está cadastrado.' });
      const result = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, passwordHash(password));
      createSession(res, Number(result.lastInsertRowid));
      return json(res, 201, { ok: true });
    }
    if (pathname === '/api/auth/login' && req.method === 'POST') {
      const body = await readBody(req);
      const user = db.prepare('SELECT * FROM users WHERE email=?').get(clean(body.email, 150).toLowerCase());
      if (!user || !passwordMatches(String(body.password || ''), user.password_hash)) return json(res, 401, { error: 'E-mail ou senha incorretos.' });
      createSession(res, user.id);
      return json(res, 200, { ok: true });
    }
    if (pathname === '/api/auth/logout' && req.method === 'POST') {
      const token = cookies(req).hydra_session;
      if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(crypto.createHash('sha256').update(token).digest('hex'));
      res.setHeader('Set-Cookie', 'hydra_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
      return json(res, 200, { ok: true });
    }
    const user = auth(req);
    if (!user) return json(res, 401, { error: 'Faça login para continuar.' });
    let farm = farmFor(user.id);
    if (pathname === '/api/me' && req.method === 'GET') return json(res, 200, { user, farm: farm || null });
    if (pathname === '/api/farm' && req.method === 'POST') {
      if (farm) return json(res, 409, { error: 'Você já possui uma fazenda cadastrada.' });
      const body = await readBody(req);
      const name = clean(body.name, 100), city = clean(body.city, 80), state = clean(body.state, 2).toUpperCase(), activity = clean(body.activity, 80);
      const area = Math.max(0, Number(body.area) || 0);
      if (name.length < 2 || city.length < 2 || state.length !== 2) return json(res, 400, { error: 'Informe nome, cidade e UF da propriedade.' });
      const result = db.prepare('INSERT INTO farms(user_id,name,city,state,area,activity) VALUES(?,?,?,?,?,?)').run(user.id, name, city, state, area, activity || 'Pecuária e agricultura');
      seedFarm(Number(result.lastInsertRowid));
      return json(res, 201, { ok: true });
    }
    if (!farm) return json(res, 428, { error: 'Cadastre sua propriedade primeiro.' });
    if (pathname === '/api/dashboard' && req.method === 'GET') return json(res, 200, dashboard(farm));
    if (pathname === '/api/animals' && req.method === 'GET') return json(res, 200, db.prepare('SELECT * FROM animals WHERE farm_id=? ORDER BY id DESC').all(farm.id));
    if (pathname === '/api/animals' && req.method === 'POST') {
      const b = await readBody(req), tag = clean(b.tag, 30).toUpperCase(), name = clean(b.name, 80), sector = clean(b.sector, 80);
      if (!tag || !name || !sector) return json(res, 400, { error: 'Informe identificação NFC, nome e setor.' });
      try {
        const result = db.prepare('INSERT INTO animals(farm_id,tag,name,species,breed,sector,status,weight) VALUES(?,?,?,?,?,?,?,?)').run(farm.id,tag,name,clean(b.species,50)||'Bovino',clean(b.breed,50),sector,clean(b.status,30)||'Saudável',Number(b.weight)||0);
        return json(res, 201, db.prepare('SELECT * FROM animals WHERE id=?').get(Number(result.lastInsertRowid)));
      } catch (e) { if (e.message.includes('UNIQUE')) return json(res,409,{error:'Esta etiqueta NFC já está cadastrada.'}); throw e; }
    }
    const animalMatch = pathname.match(/^\/api\/animals\/(\d+)$/);
    if (animalMatch && req.method === 'DELETE') {
      const result = db.prepare('DELETE FROM animals WHERE id=? AND farm_id=?').run(Number(animalMatch[1]), farm.id);
      return json(res, result.changes ? 200 : 404, result.changes ? {ok:true} : {error:'Animal não encontrado.'});
    }
    if (pathname === '/api/water' && req.method === 'GET') return json(res, 200, { reservoirs: db.prepare('SELECT * FROM reservoirs WHERE farm_id=? ORDER BY id').all(farm.id), history: dashboard(farm).history });
    if (pathname === '/api/water' && req.method === 'POST') {
      const b = await readBody(req), liters = Math.round(Number(b.liters));
      if (!liters || liters < 1) return json(res,400,{error:'Informe uma quantidade válida de litros.'});
      db.prepare('INSERT INTO water_logs(farm_id,sector,liters) VALUES(?,?,?)').run(farm.id, clean(b.sector,80)||'Geral', liters);
      return json(res,201,{ok:true});
    }
    const reservoirMatch = pathname.match(/^\/api\/reservoirs\/(\d+)$/);
    if (reservoirMatch && req.method === 'PATCH') {
      const b=await readBody(req), level=Math.min(100,Math.max(0,Math.round(Number(b.level))));
      db.prepare("UPDATE reservoirs SET level=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND farm_id=?").run(level,Number(reservoirMatch[1]),farm.id);
      return json(res,200,{ok:true});
    }
    if (pathname === '/api/drones' && req.method === 'GET') return json(res,200,db.prepare('SELECT * FROM drones WHERE farm_id=? ORDER BY id').all(farm.id));
    if (pathname === '/api/notifications' && req.method === 'GET') return json(res,200,db.prepare('SELECT * FROM notifications WHERE farm_id=? ORDER BY created_at DESC').all(farm.id));
    if (pathname === '/api/social' && req.method === 'GET') {
      ensureSocial(farm.id);
      const posts = db.prepare('SELECT * FROM posts WHERE farm_id=? ORDER BY created_at DESC').all(farm.id);
      const challenges = db.prepare('SELECT * FROM challenges WHERE farm_id=? ORDER BY id').all(farm.id);
      const ranking = [
        {position:1,name:'Fazenda Horizonte',city:'Amargosa, BA',saving:24},
        {position:2,name:farm.name,city:`${farm.city}, ${farm.state}`,saving:18,mine:true},
        {position:3,name:'Sítio Vale Verde',city:'Brejões, BA',saving:15},
        {position:4,name:'Fazenda Primavera',city:'Nova Itarana, BA',saving:12}
      ];
      return json(res,200,{posts,challenges,ranking});
    }
    if (pathname === '/api/posts' && req.method === 'POST') {
      const b=await readBody(req),content=clean(b.content,500),category=clean(b.category,50)||'Atualização';
      if(content.length<3)return json(res,400,{error:'Escreva uma atualização antes de publicar.'});
      const result=db.prepare('INSERT INTO posts(farm_id,category,content) VALUES(?,?,?)').run(farm.id,category,content);
      return json(res,201,db.prepare('SELECT * FROM posts WHERE id=?').get(Number(result.lastInsertRowid)));
    }
    const challengeMatch=pathname.match(/^\/api\/challenges\/(\d+)$/);
    if(challengeMatch&&req.method==='PATCH'){
      const b=await readBody(req),challenge=db.prepare('SELECT * FROM challenges WHERE id=? AND farm_id=?').get(Number(challengeMatch[1]),farm.id);
      if(!challenge)return json(res,404,{error:'Desafio não encontrado.'});
      const progress=Math.min(challenge.target,Math.max(0,Math.round(Number(b.progress))));
      db.prepare('UPDATE challenges SET progress=? WHERE id=? AND farm_id=?').run(progress,challenge.id,farm.id);
      return json(res,200,{ok:true});
    }
    return json(res, 404, { error: 'Rota não encontrada.' });
  } catch (error) {
    console.error(error);
    return json(res, 500, { error: 'Não foi possível concluir a operação.' });
  }
}

function serve(res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const safePath = path.normalize(requested).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(PUBLIC_DIR, safePath);
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); return res.end('Não encontrado');
  }
  const ext = path.extname(file);
  const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.json':'application/json'}[ext] || 'application/octet-stream';
  res.writeHead(200, {'Content-Type':mime,'X-Content-Type-Options':'nosniff','Cache-Control':ext==='.html'?'no-cache':'public, max-age=3600'});
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer((req,res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname.startsWith('/api/')) return api(req,res,url.pathname);
  return serve(res,url.pathname);
});
server.listen(PORT, () => console.log(`Hydra Agro disponível em http://localhost:${PORT}`));
