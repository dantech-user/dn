const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const fmt = number => new Intl.NumberFormat('pt-BR').format(Number(number || 0));
const state = { user: null, farm: null, dashboard: null, animals: [], water: null, drones: [], notifications: [], route: 'dashboard' };

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    body: options.body && typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(data.error || 'Ocorreu um erro.'); error.status = response.status; throw error; }
  return data;
}

const icon = id => `<svg aria-hidden="true"><use href="#i-${id}"/></svg>`;
function toast(message, error = false) {
  const el = $('#toast'); el.classList.toggle('error', error); el.querySelector('span').textContent = error ? '!' : '✓'; el.querySelector('p').textContent = message; el.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2800);
}
function buttonLoading(button, loading, text = 'Aguarde...') {
  if (!button.dataset.original) button.dataset.original = button.innerHTML;
  button.disabled = loading; button.innerHTML = loading ? text : button.dataset.original;
}

async function boot() {
  const started = Date.now();
  let me = null;
  try { me = await request('/api/me'); } catch (error) { if (error.status !== 401) toast(error.message, true); }
  const remaining = Math.max(0, 1850 - (Date.now() - started));
  setTimeout(() => {
    $('#splash').classList.add('out');
    if (!me) return showOnly('authView');
    state.user = me.user; state.farm = me.farm;
    if (!me.farm) return showOnly('onboardingView');
    enterApp();
  }, remaining);
}
function showOnly(id) { ['authView','onboardingView','appView'].forEach(view => $(`#${view}`).classList.toggle('hidden', view !== id)); }

$$('[data-auth]').forEach(button => button.addEventListener('click', () => {
  const register = button.dataset.auth === 'register';
  $('#loginPane').classList.toggle('hidden', register); $('#registerPane').classList.toggle('hidden', !register);
}));
$$('.show-pass').forEach(button => button.addEventListener('click', () => {
  const input = button.parentElement.querySelector('input'); input.type = input.type === 'password' ? 'text' : 'password'; button.textContent = input.type === 'password' ? 'Mostrar' : 'Ocultar';
}));

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, button = $('button[type=submit]', form), error = $('.form-error', form); error.textContent = ''; buttonLoading(button, true, 'Entrando...');
  try { await request('/api/auth/login', { method:'POST', body:Object.fromEntries(new FormData(form)) }); const me = await request('/api/me'); state.user=me.user; state.farm=me.farm; me.farm ? enterApp() : showOnly('onboardingView'); }
  catch (e) { error.textContent=e.message; } finally { buttonLoading(button,false); }
});
$('#registerForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form); error.textContent=''; buttonLoading(button,true,'Criando conta...');
  try { await request('/api/auth/register',{method:'POST',body:Object.fromEntries(new FormData(form))}); const me=await request('/api/me');state.user=me.user;showOnly('onboardingView'); }
  catch(e){error.textContent=e.message}finally{buttonLoading(button,false)}
});
$('#farmForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form);error.textContent='';buttonLoading(button,true,'Preparando sua fazenda...');
  try{await request('/api/farm',{method:'POST',body:Object.fromEntries(new FormData(form))});const me=await request('/api/me');state.farm=me.farm;toast('Fazenda configurada com sucesso!');enterApp()}catch(e){error.textContent=e.message}finally{buttonLoading(button,false)}
});

async function enterApp(){showOnly('appView');updateIdentity();await loadCore();route('dashboard')}
function updateIdentity(){const first=state.user.name.split(' ')[0];$('#userName').textContent=first;$('#userInitial').textContent=first[0].toUpperCase();$('#sideFarmName').textContent=state.farm.name;$('#topFarmName').textContent=state.farm.name}
async function loadCore(){
  try{
    [state.dashboard,state.animals,state.water,state.drones,state.notifications]=await Promise.all([request('/api/dashboard'),request('/api/animals'),request('/api/water'),request('/api/drones'),request('/api/notifications')]);
    $('#animalCountBadge').textContent=state.animals.length;const unread=state.notifications.filter(n=>!n.read).length;$('#alertBadge').textContent=unread;
  }catch(e){toast(e.message,true)}
}

function route(name){
  state.route=name;$$('[data-route]').forEach(button=>button.classList.toggle('active',button.dataset.route===name));$('.sidebar').classList.remove('open');$('#drawerBackdrop').classList.remove('show');
  const render={dashboard:renderDashboard,animals:renderAnimals,water:renderWater,drones:renderDrones,alerts:renderAlerts,settings:renderSettings}[name]||renderDashboard;render();
}
document.addEventListener('click',event=>{const button=event.target.closest('[data-route]');if(button)route(button.dataset.route);const action=event.target.closest('[data-action]');if(action?.dataset.action==='nfc')openNfc()});
$('#menuBtn').onclick=()=>{$('.sidebar').classList.add('open');$('#drawerBackdrop').classList.add('show')};
$('#drawerBackdrop').onclick=()=>{$('.sidebar').classList.remove('open');$('#drawerBackdrop').classList.remove('show')};
$('#logoutBtn').onclick=async()=>{await request('/api/auth/logout',{method:'POST'});state.user=null;state.farm=null;showOnly('authView');toast('Sessão encerrada.')};
$('#topNotifications').onclick=()=>route('alerts');

function pageHead(label,title,description,actions=''){return `<div class="page-head"><div><span class="label">${label}</span><h1>${title}</h1><p>${description}</p></div><div class="head-actions">${actions}</div></div>`}
function renderDashboard(){
  const d=state.dashboard,first=esc(state.user.name.split(' ')[0]),low=d.reservoirs.find(r=>r.level<30),percent=Math.min(100,Math.round((d.todayWater/d.waterGoal)*100));
  const hour=new Date().getHours(),greeting=hour<12?'Bom dia':hour<18?'Boa tarde':'Boa noite';
  $('#pageRoot').innerHTML=`<div class="page-enter">
    <div class="hello-row"><div><span class="date">${new Intl.DateTimeFormat('pt-BR',{weekday:'long',day:'2-digit',month:'long'}).format(new Date()).toUpperCase()}</span><h1>${greeting}, ${first}.</h1><p>Sua fazenda está funcionando bem hoje.</p></div><div class="weather"><span class="weather-icon">☀</span><div><strong>28 °C</strong><small>Brejões, BA · Ensolarado</small></div></div></div>
    ${low?`<div class="warning-banner">${icon('alert')}<div><strong>Atenção necessária</strong><p>${esc(low.name)} está com ${low.level}% da capacidade.</p></div><button data-route="water">Ver detalhes</button></div>`:''}
    <div class="section-title"><div><span class="label">VISÃO GERAL</span><h2>Hoje na fazenda</h2></div><button>Atualizado agora</button></div>
    <div class="metric-grid">
      ${metric('water','drop','Consumo de água',`${fmt(d.todayWater)} <small>L</small>`,'meta diária de '+fmt(d.waterGoal)+' L',percent,'−8%')}
      ${metric('animals','cow','Animais monitorados',fmt(d.animalStats.total),`${fmt(d.animalStats.healthy)} em situação normal`,Math.round((d.animalStats.healthy/d.animalStats.total)*100),'+3')}
      ${metric('drone','drone','Drones ativos',`${d.dronesActive} <small>/ ${state.drones.length}</small>`,'inspeções em andamento',state.drones.length?d.dronesActive/state.drones.length*100:0,'Ao vivo')}
      ${metric('alerts','bell','Alertas abertos',state.notifications.length,`${d.animalStats.attention||0} animais em observação`,Math.min(100,state.notifications.length*18),'Novos')}
    </div>
    <div class="dashboard-grid">
      <article class="panel"><div class="panel-title"><div><span class="label">GESTÃO HÍDRICA</span><h3>Consumo de água hoje</h3></div><button data-route="water">Ver relatório →</button></div><div class="water-summary"><div class="donut" style="--progress:${percent}%"><div><strong>${percent}%</strong><small>DA META DIÁRIA</small></div></div><div class="water-kpis"><div><span>UTILIZADO</span><strong>${fmt(d.todayWater)} L</strong></div><div><span>DISPONÍVEL</span><strong class="green">${fmt(Math.max(0,d.waterGoal-d.todayWater))} L</strong></div><div><span>META</span><strong>${fmt(d.waterGoal)} L</strong></div><div><span>ECONOMIA</span><strong class="orange">−12%</strong></div></div></div></article>
      <article class="panel"><div class="panel-title"><div><span class="label">TEMPO REAL</span><h3>Atividades recentes</h3></div><button data-route="alerts">Ver tudo →</button></div><ul class="activity-list">${d.notifications.slice(0,4).map(n=>activity(n)).join('')}</ul></article>
    </div></div>`;
}
function metric(cls,ico,label,value,caption,progress,change){return `<article class="metric-card ${cls}"><div class="metric-top"><span class="metric-icon">${icon(ico)}</span><b class="metric-change">${change}</b></div><span>${label}</span><strong>${value}</strong><p>${caption}</p><div class="metric-track"><i style="width:${Math.min(100,progress)}%"></i></div></article>`}
function activity(n){const ico=n.type==='animal'?'cow':n.type==='success'?'drop':'alert';return `<li><span class="activity-bubble ${esc(n.type)}">${icon(ico)}</span><div><strong>${esc(n.title)}</strong><small>${esc(n.message)}</small></div><time>${shortDate(n.created_at)}</time></li>`}

function renderAnimals(filter=''){
  const list=state.animals.filter(a=>`${a.name} ${a.tag} ${a.breed} ${a.sector}`.toLowerCase().includes(filter.toLowerCase()));
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('REBANHO','Animais','Identificação, localização e saúde do rebanho.',`<button class="btn outline" data-action="nfc">${icon('nfc')} Ler NFC</button><button class="btn orange" id="addAnimal">${icon('plus')} Novo animal</button>`)}
  <div class="metric-grid"><article class="metric-card animals"><span>Total cadastrado</span><strong>${state.animals.length}</strong><p>animais identificados</p></article><article class="metric-card water"><span>Saudáveis</span><strong>${state.animals.filter(a=>a.status==='Saudável').length}</strong><p>situação normal</p></article><article class="metric-card alerts"><span>Em observação</span><strong>${state.animals.filter(a=>a.status!=='Saudável').length}</strong><p>precisam de atenção</p></article><article class="metric-card drone"><span>Com etiqueta NFC</span><strong>100%</strong><p>do rebanho cadastrado</p></article></div>
  <div class="section-title"><div><span class="label">CADASTROS</span><h2>Todos os animais</h2></div></div><div class="toolbar"><div class="search-box">${icon('search')}<input id="animalSearch" placeholder="Busque por nome, etiqueta ou setor" value="${esc(filter)}"></div></div>
  <article class="panel table-panel"><div class="table-scroll"><table class="data-table"><thead><tr><th>ANIMAL</th><th>SETOR</th><th>PESO</th><th>ÚLTIMA LEITURA</th><th>STATUS</th><th></th></tr></thead><tbody>${list.map(animalRow).join('')}</tbody></table>${list.length?'':'<div class="empty-state">Nenhum animal encontrado.</div>'}</div></article></div>`;
  $('#animalSearch').oninput=e=>renderAnimals(e.target.value);$('#addAnimal').onclick=openAnimalForm;$$('[data-delete-animal]').forEach(b=>b.onclick=()=>deleteAnimal(Number(b.dataset.deleteAnimal)));
}
function animalRow(a){return `<tr><td><div class="animal-cell"><span class="animal-avatar">${icon('cow')}</span><div><strong>${esc(a.name)}</strong><small>${esc(a.tag)} · ${esc(a.species)} ${esc(a.breed)}</small></div></div></td><td>${esc(a.sector)}</td><td>${a.weight?`${fmt(a.weight)} kg`:'—'}</td><td>${shortDate(a.last_seen)}</td><td><span class="status-pill ${a.status==='Saudável'?'':'watch'}">${esc(a.status)}</span></td><td><button class="row-action" data-delete-animal="${a.id}">Excluir</button></td></tr>`}
function openAnimalForm(prefill=''){
  openModal('NOVO CADASTRO','Adicionar animal',`<form id="animalForm" class="modal-form"><label>Etiqueta NFC<input name="tag" value="${esc(prefill)}" placeholder="AG-0001" required></label><label>Nome do animal<input name="name" placeholder="Ex.: Estrela" required></label><label>Espécie<select name="species"><option>Bovino</option><option>Equino</option><option>Ovino</option><option>Caprino</option></select></label><label>Raça<input name="breed" placeholder="Ex.: Nelore"></label><label>Setor<input name="sector" placeholder="Ex.: Pasto Sul" required></label><label>Peso (kg)<input type="number" name="weight" min="0" placeholder="0"></label><label class="full">Situação<select name="status"><option>Saudável</option><option>Observação</option><option>Tratamento</option></select></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Salvar animal</button></form>`);
  $('#animalForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,button=$('button[type=submit]',form);buttonLoading(button,true,'Salvando...');try{await request('/api/animals',{method:'POST',body:Object.fromEntries(new FormData(form))});state.animals=await request('/api/animals');$('#animalCountBadge').textContent=state.animals.length;closeModal();renderAnimals();toast('Animal cadastrado no banco de dados.')}catch(err){$('.form-error',form).textContent=err.message}finally{buttonLoading(button,false)}};
}
async function deleteAnimal(id){if(!confirm('Deseja excluir este animal do cadastro?'))return;try{await request(`/api/animals/${id}`,{method:'DELETE'});state.animals=state.animals.filter(a=>a.id!==id);renderAnimals();toast('Animal removido.')}catch(e){toast(e.message,true)}}

function renderWater(){
  const w=state.water, max=Math.max(...w.history.map(h=>h.liters),1);
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('GESTÃO HÍDRICA','Água','Reservatórios, consumo e metas de economia.',`<button class="btn orange" id="addWater">${icon('plus')} Registrar consumo</button>`)}
  <div class="reservoir-grid">${w.reservoirs.map(r=>`<article class="reservoir-card"><div class="card-top"><div><h3>${esc(r.name)}</h3><p>${esc(r.sector)} · ${fmt(r.capacity)} L</p></div><strong class="level-number ${r.level<30?'low':''}">${r.level}%</strong></div><div class="level-track ${r.level<30?'low':''}"><i style="width:${r.level}%"></i></div><div class="card-foot"><span>Nível atual</span><button class="row-action" data-reservoir="${r.id}" data-level="${r.level}">Atualizar</button></div></article>`).join('')}</div>
  <article class="panel" style="margin-top:14px"><div class="panel-title"><div><span class="label">ÚLTIMOS 7 DIAS</span><h3>Histórico de consumo</h3></div><strong class="green" style="font-size:10px">−12% esta semana</strong></div><div class="chart">${w.history.map(h=>`<div class="chart-col"><strong>${fmt(h.liters)} L</strong><i style="height:${Math.max(12,h.liters/max*86)}%"></i><span>${dayLabel(h.day)}</span></div>`).join('')}</div></article></div>`;
  $('#addWater').onclick=openWaterForm;$$('[data-reservoir]').forEach(b=>b.onclick=()=>updateReservoir(b.dataset.reservoir,b.dataset.level));
}
function openWaterForm(){openModal('NOVA LEITURA','Registrar consumo',`<form id="waterForm" class="modal-form"><label class="full">Setor<input name="sector" placeholder="Ex.: Irrigação do cacau" required></label><label class="full">Quantidade utilizada (litros)<input type="number" name="liters" min="1" placeholder="Ex.: 680" required></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Salvar leitura</button></form>`);$('#waterForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;try{await request('/api/water',{method:'POST',body:Object.fromEntries(new FormData(form))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Consumo registrado no banco de dados.')}catch(err){$('.form-error',form).textContent=err.message}}}
function updateReservoir(id,current){openModal('NÍVEL DO RESERVATÓRIO','Atualizar medição',`<form id="levelForm" class="modal-form"><label class="full">Nível atual: <b id="levelOutput">${current}%</b><input type="range" name="level" min="0" max="100" value="${current}" style="padding:0"></label><div class="form-error full"></div><button class="btn orange wide full" type="submit">Atualizar nível</button></form>`);$('[name=level]').oninput=e=>$('#levelOutput').textContent=e.target.value+'%';$('#levelForm').onsubmit=async e=>{e.preventDefault();try{await request(`/api/reservoirs/${id}`,{method:'PATCH',body:Object.fromEntries(new FormData(e.currentTarget))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Reservatório atualizado.')}catch(err){toast(err.message,true)}}}

function renderDrones(){
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('MONITORAMENTO AÉREO','Drones','Inspeções inteligentes em toda a propriedade.',`<button class="btn orange" id="newMission">${icon('plus')} Nova missão</button>`)}<div class="drone-grid">${state.drones.map(d=>`<article class="drone-card"><div class="card-top"><div><h3>${esc(d.name)}</h3><p>${esc(d.model)}</p></div><span class="drone-status ${d.status==='Em voo'?'':'base'}">● ${esc(d.status)}</span></div><div class="drone-visual">${icon('drone')}</div><div class="drone-info"><span>${esc(d.mission)}</span><strong>${d.battery}%</strong></div><div class="level-track"><i style="width:${d.battery}%"></i></div></article>`).join('')}</div><article class="panel" style="margin-top:14px"><div class="panel-title"><div><span class="label">COBERTURA</span><h3>Operações da propriedade</h3></div></div><div class="warning-banner" style="margin:0;background:#edf5ef;border-color:#d7e8db;border-left-color:var(--green)">${icon('drone')}<div><strong>2 missões em andamento</strong><p>Monitoramento do rebanho e inspeção da plantação de cacau.</p></div></div></article></div>`;
  $('#newMission').onclick=()=>toast('Planejador de missão preparado para integração com o drone.');
}
function renderAlerts(){
  $('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('CENTRAL DE AVISOS','Alertas','Tudo que precisa da sua atenção na fazenda.')}<div class="notice-list">${state.notifications.map(n=>`<article class="notice-card"><span class="notice-icon ${esc(n.type)}">${icon(n.type==='animal'?'cow':n.type==='success'?'drop':'alert')}</span><div><strong>${esc(n.title)}</strong><p>${esc(n.message)}</p><time>${longDate(n.created_at)}</time></div></article>`).join('')}</div></div>`;
}
function renderSettings(){const initials=state.user.name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();$('#pageRoot').innerHTML=`<div class="page-enter">${pageHead('PREFERÊNCIAS','Configurações','Dados da conta e da propriedade.')}<div class="settings-layout"><article class="panel profile-panel"><div class="big-avatar">${esc(initials)}</div><h2>${esc(state.user.name)}</h2><p>${esc(state.user.email)}<br>Administrador da propriedade</p><div class="farm-info"><div><span>Propriedade</span><strong>${esc(state.farm.name)}</strong></div><div><span>Localização</span><strong>${esc(state.farm.city)} · ${esc(state.farm.state)}</strong></div><div><span>Área</span><strong>${fmt(state.farm.area)} ha</strong></div></div></article><div class="settings-list"><button class="setting-card">${settingIcon('home')}<div><strong>Dados da propriedade</strong><small>Nome, localização, área e atividade</small></div><b>›</b></button><button class="setting-card" data-route="water">${settingIcon('drop')}<div><strong>Meta de consumo</strong><small>Objetivo atual: ${fmt(state.farm.water_goal)} litros por dia</small></div><b>›</b></button><button class="setting-card" data-route="alerts">${settingIcon('bell')}<div><strong>Notificações e alertas</strong><small>Água, animais e operações aéreas</small></div><b>›</b></button><button class="setting-card" id="settingsLogout">${settingIcon('logout')}<div><strong>Sair da conta</strong><small>Encerrar a sessão neste dispositivo</small></div><b>›</b></button></div></div></div>`;$('#settingsLogout').onclick=()=>$('#logoutBtn').click()}
function settingIcon(name){return `<span>${icon(name)}</span>`}

function openModal(label,title,body){$('#modalLabel').textContent=label;$('#modalTitle').textContent=title;$('#modalBody').innerHTML=body;$('#appModal').showModal()}
function closeModal(){$('#appModal').close()}$$('[data-close]').forEach(b=>b.onclick=closeModal);$('#appModal').addEventListener('click',e=>{if(e.target===$('#appModal'))closeModal()});
async function openNfc(){
  openModal('IDENTIFICAÇÃO','Leitor NFC',`<div class="nfc-scan"><div class="nfc-rings"><i></i><i></i>${icon('nfc')}</div><h3>Aproxime a etiqueta</h3><p id="nfcStatus">Encoste o celular no brinco NFC do animal.</p><button id="simulateNfc" class="btn soft wide">Simular etiqueta AG-${String(Math.floor(Math.random()*9000)+1000)}</button></div>`);
  $('#simulateNfc').onclick=()=>{const tag=$('#simulateNfc').textContent.match(/AG-\d+/)?.[0]||'AG-0001';closeModal();openAnimalForm(tag)};
  if('NDEFReader' in window){try{const reader=new NDEFReader();await reader.scan();$('#nfcStatus').textContent='Leitor ativo. Aproxime a etiqueta NFC.';reader.onreading=event=>{let tag=event.serialNumber||'';for(const record of event.message.records){if(record.recordType==='text')tag=new TextDecoder(record.encoding||'utf-8').decode(record.data)}closeModal();openAnimalForm(tag||'NFC-LIDO')}}catch(e){$('#nfcStatus').textContent='Permissão NFC não concedida. Use a simulação abaixo.'}}
}
function shortDate(value){const date=new Date(String(value).replace(' ','T')+'Z');return new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(date)}
function longDate(value){const date=new Date(String(value).replace(' ','T')+'Z');return new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}).format(date)}
function dayLabel(value){const date=new Date(value+'T12:00:00');return new Intl.DateTimeFormat('pt-BR',{weekday:'short'}).format(date).replace('.','')}
boot();
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
