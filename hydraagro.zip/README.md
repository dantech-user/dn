# Hydra Agro

Aplicação full-stack para gestão de propriedades rurais, animais identificados por NFC, água, reservatórios, drones e alertas.

## Executar no GitHub Codespaces

1. Envie todos os arquivos para um repositório no GitHub.
2. Abra **Code → Codespaces → Create codespace on main**.
3. Aguarde a preparação. O Hydra Agro iniciará automaticamente.
4. Quando aparecer a notificação da porta `4173`, clique em **Open in Browser**.

Se precisar iniciar manualmente no terminal:

```bash
npm start
```

Na aba **Ports**, a porta `4173` deve estar com visibilidade **Public** para abrir o aplicativo em outros aparelhos durante a feira.

## Executar em outro ambiente

Requer Node.js 22.5 ou superior.

```bash
npm start
```

Acesse `http://localhost:4173`. O banco SQLite é criado automaticamente em `data/hydra-agro.sqlite`.

## Primeiro acesso

Crie uma conta e cadastre sua propriedade. O sistema insere dados iniciais de demonstração que podem ser consultados e alterados pela interface.
