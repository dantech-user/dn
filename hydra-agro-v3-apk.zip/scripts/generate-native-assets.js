const fs = require('node:fs');
const zlib = require('node:zlib');
const path = require('node:path');

const crcTable = Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0});
function crc32(buffer){let c=0xffffffff;for(const byte of buffer)c=crcTable[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0}
function chunk(type,data){const name=Buffer.from(type);const length=Buffer.alloc(4);length.writeUInt32BE(data.length);const crc=Buffer.alloc(4);crc.writeUInt32BE(crc32(Buffer.concat([name,data])));return Buffer.concat([length,name,data,crc])}
function makeCanvas(size,background=[0,0,0,0]){const pixels=Buffer.alloc(size*size*4);for(let i=0;i<pixels.length;i+=4){pixels[i]=background[0];pixels[i+1]=background[1];pixels[i+2]=background[2];pixels[i+3]=background[3]}return{size,pixels}}
function setPixel(canvas,x,y,color){if(x<0||y<0||x>=canvas.size||y>=canvas.size)return;const i=(Math.floor(y)*canvas.size+Math.floor(x))*4;canvas.pixels[i]=color[0];canvas.pixels[i+1]=color[1];canvas.pixels[i+2]=color[2];canvas.pixels[i+3]=color[3]}
function ellipse(canvas,cx,cy,rx,ry,angle,color){const cos=Math.cos(angle),sin=Math.sin(angle);const reach=Math.ceil(Math.max(rx,ry));for(let y=Math.floor(cy-reach);y<=cy+reach;y++)for(let x=Math.floor(cx-reach);x<=cx+reach;x++){const dx=x-cx,dy=y-cy,u=dx*cos+dy*sin,v=-dx*sin+dy*cos;if((u*u)/(rx*rx)+(v*v)/(ry*ry)<=1)setPixel(canvas,x,y,color)}}
function line(canvas,x0,y0,x1,y1,width,color){const steps=Math.ceil(Math.hypot(x1-x0,y1-y0));for(let s=0;s<=steps;s++){const t=s/steps,cx=x0+(x1-x0)*t,cy=y0+(y1-y0)*t;ellipse(canvas,cx,cy,width/2,width/2,0,color)}}
function droplet(canvas,cx,top,height,color){const bottom=top+height;for(let y=Math.floor(top);y<=bottom;y++){const t=(y-top)/height;const half=Math.sin(Math.PI*Math.pow(t,.72))*height*.25;for(let x=Math.floor(cx-half);x<=cx+half;x++)setPixel(canvas,x,y,color)}}
function drawMark(canvas,scale=1){const s=canvas.size,cx=s/2;droplet(canvas,cx,s*.18*scale+s*.5*(1-scale),s*.27*scale,[255,138,18,255]);ellipse(canvas,cx-s*.115*scale,s*.56*scale+s*.5*(1-scale),s*.19*scale,s*.095*scale,-.72,[162,189,66,255]);ellipse(canvas,cx+s*.115*scale,s*.56*scale+s*.5*(1-scale),s*.19*scale,s*.095*scale,.72,[255,255,255,255]);line(canvas,cx-s*.2*scale,s*.66*scale+s*.5*(1-scale),cx-s*.02*scale,s*.48*scale+s*.5*(1-scale),s*.012*scale,[34,94,50,255]);line(canvas,cx+s*.2*scale,s*.66*scale+s*.5*(1-scale),cx+s*.02*scale,s*.48*scale+s*.5*(1-scale),s*.012*scale,[11,81,54,255])}
function writePng(file,canvas){const {size,pixels}=canvas;const raw=Buffer.alloc((size*4+1)*size);for(let y=0;y<size;y++){const start=y*(size*4+1);raw[start]=0;pixels.copy(raw,start+1,y*size*4,(y+1)*size*4)}const header=Buffer.alloc(13);header.writeUInt32BE(size,0);header.writeUInt32BE(size,4);header[8]=8;header[9]=6;const png=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',zlib.deflateSync(raw,{level:9})),chunk('IEND',Buffer.alloc(0))]);fs.writeFileSync(file,png)}

const target=path.join(__dirname,'..','assets');fs.mkdirSync(target,{recursive:true});
let canvas=makeCanvas(1024,[11,81,54,255]);drawMark(canvas,.72);writePng(path.join(target,'icon-only.png'),canvas);
canvas=makeCanvas(1024,[0,0,0,0]);drawMark(canvas,.62);writePng(path.join(target,'icon-foreground.png'),canvas);
canvas=makeCanvas(1024,[11,81,54,255]);writePng(path.join(target,'icon-background.png'),canvas);
canvas=makeCanvas(2732,[11,81,54,255]);drawMark(canvas,.42);writePng(path.join(target,'splash.png'),canvas);writePng(path.join(target,'splash-dark.png'),canvas);
fs.mkdirSync(path.join(__dirname,'..','public','assets'),{recursive:true});
fs.copyFileSync(path.join(target,'icon-only.png'),path.join(__dirname,'..','public','assets','app-icon.png'));
console.log('Ícones e splash nativa gerados em assets/.');
