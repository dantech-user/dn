const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
const number = value => new Intl.NumberFormat('pt-BR').format(Number(value || 0));
const state = {user:null,farm:null,dashboard:null,animals:[],water:{reservoirs:[],history:[]},drones:[],notifications:[],social:{posts:[],challenges:[],ranking:[]},route:'dashboard'};
const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;

async function request(url, options = {}) {
  const base = String(window.HYDRA_API_URL || '').replace(/\/$/, '');
  const response = await fetch(base + url, {
    credentials: 'include', ...options,
    headers: {'Content-Type':'application/json',...(options.headers||{})},
    body: options.body && typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(data.error || 'Não foi possível concluir.'); error.status=response.status; throw error; }
  return data;
}

function showOnly(id){['authView','onboardingView','appView'].forEach(view=>$(`#${view}`).classList.toggle('hidden',view!==id))}
function toast(message,isError=false){const el=$('#toast');el.classList.toggle('error',isError);$('b',el).textContent=isError?'!':'✓';$('span',el).textContent=message;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2800)}
function loading(button,active,label='Aguarde...'){if(!button.dataset.original)button.dataset.original=button.innerHTML;button.disabled=active;button.innerHTML=active?label:button.dataset.original}

async function boot(){
  const start=Date.now();let me=null;
  try{me=await request('/api/me')}catch(error){if(error.status!==401)toast(error.message,true)}
  setTimeout(()=>{ $('#splash').classList.add('out'); if(!me)return showOnly('authView'); state.user=me.user;state.farm=me.farm;me.farm?enterApp():showOnly('onboardingView') },Math.max(0,1900-(Date.now()-start)));
}

$$('[data-auth]').forEach(button=>button.onclick=()=>{const register=button.dataset.auth==='register';$('#loginPane').classList.toggle('hidden',register);$('#registerPane').classList.toggle('hidden',!register)});
$$('.show-pass').forEach(button=>button.onclick=()=>{const input=$('input',button.parentElement);input.type=input.type==='password'?'text':'password'});

$('#loginForm').onsubmit=async event=>{
  event.preventDefault();const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form);error.textContent='';loading(button,true,'Entrando...');
  try{await request('/api/auth/login',{method:'POST',body:Object.fromEntries(new FormData(form))});const me=await request('/api/me');state.user=me.user;state.farm=me.farm;me.farm?enterApp():showOnly('onboardingView')}catch(e){error.textContent=e.message}finally{loading(button,false)}
};
$('#registerForm').onsubmit=async event=>{
  event.preventDefault();const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form);error.textContent='';loading(button,true,'Criando conta...');
  try{await request('/api/auth/register',{method:'POST',body:Object.fromEntries(new FormData(form))});const me=await request('/api/me');state.user=me.user;showOnly('onboardingView')}catch(e){error.textContent=e.message}finally{loading(button,false)}
};
$('#farmForm').onsubmit=async event=>{
  event.preventDefault();const form=event.currentTarget,button=$('button[type=submit]',form),error=$('.form-error',form);error.textContent='';loading(button,true,'Preparando...');
  try{await request('/api/farm',{method:'POST',body:Object.fromEntries(new FormData(form))});const me=await request('/api/me');state.farm=me.farm;await enterApp();toast('Sua fazenda está pronta!')}catch(e){error.textContent=e.message}finally{loading(button,false)}
};

async function loadAll(){
  [state.dashboard,state.animals,state.water,state.drones,state.notifications,state.social]=await Promise.all([request('/api/dashboard'),request('/api/animals'),request('/api/water'),request('/api/drones'),request('/api/notifications'),request('/api/social')]);
}
async function enterApp(){showOnly('appView');try{await loadAll();route('dashboard')}catch(e){toast(e.message,true)}}
function route(name){state.route=name;$$('.bottom-nav [data-route]').forEach(button=>button.classList.toggle('active',button.dataset.route===name));const screens={dashboard:renderHome,community:renderCommunity,challenges:renderChallenges,profile:renderProfile,animals:renderAnimals,water:renderWater,drones:renderDrones,alerts:renderAlerts};(screens[name]||renderHome)();scrollTo({top:0,behavior:'smooth'})}
document.addEventListener('click',event=>{const routeButton=event.target.closest('[data-route]');if(routeButton)route(routeButton.dataset.route);const action=event.target.closest('[data-action]');if(action?.dataset.action==='create')openQuickMenu();if(action?.dataset.action==='nfc')openNfc()});

function renderHome(){
  const d=state.dashboard,first=esc(state.user.name.split(' ')[0]),goal=d.waterGoal||3500,pct=Math.min(100,Math.round((d.todayWater/goal)*100)||0),low=d.reservoirs.find(r=>r.level<30);
  $('#pageRoot').innerHTML=`<section class="screen home-screen">
    <div class="brand-row"><div class="mini-brand"><img src="/logo.svg" alt=""><strong>Hydra <span>Agro</span></strong></div><button class="icon-button" data-route="alerts">${icon('bell')}<i class="dot"></i></button></div>
    <div class="home-greeting"><div><h1>Boa tarde, ${first}</h1><p>Que bom te ver por aqui!</p></div><span class="weather-sun">☀</span></div>
    <div class="shortcut-row"><button data-route="animals"><span>${icon('cow')}</span>Rebanho</button><button data-route="water"><span>${icon('drop')}</span>Água</button><button data-route="drones"><span>${icon('drone')}</span>Drones</button><button data-route="challenges"><span>${icon('target')}</span>Metas</button></div>
    <article class="summary-card"><div class="summary-top"><h2>${esc(state.farm.name)}</h2><button class="icon-button" data-route="profile" style="color:white">${icon('chevron')}</button></div><div class="summary-label">Resumo diário &nbsp; · &nbsp; ${new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'long'}).format(new Date())}</div><div class="summary-body"><div class="summary-values"><div class="summary-value">${icon('drop')}<div><span>Água utilizada</span><strong>${number(d.todayWater)} L</strong></div></div><div class="summary-value">${icon('cow')}<div><span>Animais</span><strong>${number(d.animalStats.total)}</strong></div></div><div class="summary-value">${icon('drone')}<div><span>Drones voando</span><strong>${number(d.dronesActive)}</strong></div></div></div><div class="progress-ring" style="--progress:${pct}%"><div><strong>${pct}%</strong><small>da meta diária de água</small></div></div></div><div class="summary-footer"><span>Ver detalhes</span><span>›</span></div></article>
    <div class="section-heading"><h2>Alertas</h2><button data-route="alerts">Ver todos</button></div>
    <article class="card alert-card"><span class="alert-icon">${icon(low?'drop':'leaf')}</span><div><strong>${low?'Nível de água baixo':'Ótimo desempenho!'}</strong><small>${low?`${esc(low.name)} está com ${low.level}%.`:'Consumo de água 18% menor que ontem.'}</small></div><time>08:15</time></article>
  </section>`;
}

function communityPost(post,index){
  const first=index===0,kind=post.category?.includes('água')?'drop':post.category==='Rebanho'?'cow':'drone';
  return `<article class="card post"><header class="post-header"><span class="farm-avatar">FB</span><div><strong>${esc(state.farm.name)}</strong><small>${esc(state.farm.city)} - ${esc(state.farm.state)} · ${ago(post.created_at)}</small></div><button>•••</button></header><p class="post-text">${esc(post.content)}</p>${first?`<div class="post-cover"><img src="/assets/water-saving-cover.png" alt="Irrigação sustentável"><div class="cover-copy"><strong>ECONOMIA QUE TRANSFORMA</strong><div class="saving-badge"><b>-12%</b><small>de água<br>esta semana</small></div></div></div>`:`<div class="simple-cover">${icon(kind)}<strong>${kind==='cow'?'Tecnologia cuidando do rebanho.':'O campo visto de cima.'}</strong></div>`}<footer class="post-actions"><button data-like>${icon('heart')} <span>${post.reactions}</span></button><button>${icon('comment')} ${post.comments}</button><button class="bookmark">${icon('bookmark')}</button></footer></article>`;
}
function renderCommunity(){
  $('#pageRoot').innerHTML=`<section class="screen"><header class="screen-header"><h1>Comunidade</h1><div class="header-actions"><button class="icon-button">${icon('search')}</button><button class="icon-button">${icon('filter')}</button></div></header><div class="community-tabs"><button class="active">Todos</button><button>Seguindo</button><button>Minhas fazendas</button></div><div class="card composer"><span class="farm-avatar">${esc(state.user.name[0])}</span><button id="composerButton">Compartilhe uma conquista...</button>${icon('leaf')}</div><div class="feed">${state.social.posts.map(communityPost).join('')}</div></section>`;
  $('#composerButton').onclick=openPostForm;$$('[data-like]').forEach(button=>button.onclick=()=>{if(!button.classList.toggle('liked'))return;const value=$('span',button);value.textContent=Number(value.textContent)+1;toast('Você apoiou esta publicação.')});
}

function challengeCard(challenge,index){const pct=Math.min(100,Math.round(challenge.progress/challenge.target*100));return `<article class="card challenge-card"><div class="challenge-main"><span class="challenge-icon">${icon(index===0?'drop':index===1?'cow':'drone')}</span><div><strong>${esc(challenge.title)}</strong><p>${esc(challenge.description)}</p></div><b>${challenge.progress}/${challenge.target}</b></div><div class="progress-bar ${index===1?'green':''}"><i style="width:${pct}%"></i></div><footer><span>Recompensa: ${index===0?'🌿 150':'🏅 200'} pontos</span><button data-progress="${challenge.id}" data-value="${challenge.progress+1}" ${pct===100?'disabled':''}>${pct===100?'Concluído':'Registrar +1'}</button></footer></article>`}
function renderChallenges(){
  const mine=state.social.ranking.find(item=>item.mine)||{position:2,saving:18};
  $('#pageRoot').innerHTML=`<section class="screen"><header class="screen-header"><h1>Desafios</h1><button class="icon-button">${icon('info')}</button></header><article class="ranking-hero"><div class="hero-main"><span class="trophy-circle">${icon('trophy')}</span><div><small>Você está em</small><strong>${mine.position}º lugar</strong><span>no ranking geral</span></div></div><footer><span>Ver ranking completo</span><span>›</span></footer></article><div class="section-heading"><h2>Seus desafios</h2></div><div class="challenge-list">${state.social.challenges.map(challengeCard).join('')}</div><div class="section-heading"><h2>Ranking geral</h2><button>Ver tudo</button></div><article class="card ranking-list">${state.social.ranking.map(rank=>`<div class="rank-row ${rank.mine?'mine':''}"><b>${rank.position}</b><span>${rank.name.split(' ').map(p=>p[0]).slice(0,2).join('')}</span><div><strong>${esc(rank.name)}</strong><small>${esc(rank.city)}</small></div><em>${rank.saving}%</em></div>`).join('')}</article></section>`;
  $$('[data-progress]').forEach(button=>button.onclick=()=>updateChallenge(button.dataset.progress,button.dataset.value));
}

function renderProfile(){
  $('#pageRoot').innerHTML=`<section class="screen"><header class="profile-header"><button class="icon-button back-button" data-route="dashboard">${icon('back')}</button><button class="icon-button">•••</button></header><div class="profile-hero"><span class="farm-profile-avatar"><img src="/logo.svg" alt=""></span><h1>${esc(state.farm.name)}</h1><p>${icon('location')} ${esc(state.farm.city)} - ${esc(state.farm.state)}</p></div><article class="card profile-stats"><div>${icon('cow')}<strong>${state.animals.length}</strong><small>Animais</small></div><div>${icon('drop')}<strong>-18%</strong><small>Economia de água<br>(30 dias)</small></div><div>${icon('target')}<strong>12</strong><small>Missões<br>concluídas</small></div></article><article class="card settings-card"><button class="settings-row"><svg><use href="#i-clipboard"/></svg><span>Informações da fazenda</span>${icon('chevron')}</button><button class="settings-row"><svg><use href="#i-users"/></svg><span>Equipe</span>${icon('chevron')}</button><button class="settings-row" data-route="drones"><svg><use href="#i-drone"/></svg><span>Dispositivos conectados</span><b>${state.drones.length}</b>${icon('chevron')}</button><button class="settings-row"><svg><use href="#i-trophy"/></svg><span>Planos e assinaturas</span>${icon('chevron')}</button><button class="settings-row" data-route="alerts"><svg><use href="#i-bell"/></svg><span>Notificações</span>${icon('chevron')}</button><button class="settings-row"><svg><use href="#i-settings"/></svg><span>Configurações</span>${icon('chevron')}</button><button class="settings-row logout-row" id="logoutButton">${icon('logout')}<span>Sair da conta</span>${icon('chevron')}</button></article></section>`;
  $('#logoutButton').onclick=logout;
}

function subHeader(title,action=''){return `<div class="subpage-title"><button class="icon-button back-button" data-route="dashboard">${icon('back')}</button><h1>${title}</h1>${action}</div>`}
function renderAnimals(filter=''){
  const list=state.animals.filter(animal=>`${animal.name} ${animal.tag} ${animal.breed} ${animal.sector}`.toLowerCase().includes(filter.toLowerCase()));
  $('#pageRoot').innerHTML=`<section class="screen">${subHeader('Rebanho',`<button class="primary-small" id="addAnimal">+ Novo animal</button>`)}<div class="search-bar">${icon('search')}<input id="animalSearch" placeholder="Buscar por nome ou etiqueta" value="${esc(filter)}"></div><div class="animal-list">${list.map(animal=>`<article class="card animal-row"><span class="animal-bubble">${icon('cow')}</span><div><strong>${esc(animal.name)}</strong><small>${esc(animal.tag)} · ${esc(animal.breed)} · ${esc(animal.sector)}</small></div><span class="status ${animal.status==='Saudável'?'':'watch'}">${esc(animal.status)}</span></article>`).join('')||'<div class="empty">Nenhum animal encontrado.</div>'}</div></section>`;
  $('#animalSearch').oninput=e=>renderAnimals(e.target.value);$('#addAnimal').onclick=()=>openAnimalForm();
}
function renderWater(){
  const max=Math.max(...state.water.history.map(item=>item.liters),1);
  $('#pageRoot').innerHTML=`<section class="screen">${subHeader('Gestão da água',`<button class="primary-small" id="addWater">+ Consumo</button>`)}<div class="reservoir-list">${state.water.reservoirs.map(item=>`<article class="card reservoir-row"><div class="row-top"><div><h3>${esc(item.name)}</h3><p>${esc(item.sector)} · ${number(item.capacity)} L</p></div><b class="${item.level<30?'low':''}">${item.level}%</b></div><div class="level-track"><i class="${item.level<30?'low':''}" style="width:${item.level}%"></i></div><div class="row-foot"><span>Nível atual</span><button data-reservoir="${item.id}" data-level="${item.level}">Atualizar</button></div></article>`).join('')}</div><div class="section-heading"><h2>Últimos 7 dias</h2><button>−12% esta semana</button></div><article class="card charts">${state.water.history.map(item=>`<div class="chart-col"><i style="height:${Math.max(12,item.liters/max*88)}%"></i><small>${weekday(item.day)}</small></div>`).join('')}</article></section>`;
  $('#addWater').onclick=openWaterForm;$$('[data-reservoir]').forEach(button=>button.onclick=()=>openReservoirForm(button.dataset.reservoir,button.dataset.level));
}
function renderDrones(){
  $('#pageRoot').innerHTML=`<section class="screen">${subHeader('Drones',`<button class="primary-small" id="newMission">+ Missão</button>`)}<div class="drone-list">${state.drones.map(drone=>`<article class="card drone-row"><div class="row-top"><div><h3>${esc(drone.name)}</h3><p>${esc(drone.model)}</p></div><b style="font-size:10px">${esc(drone.status)}</b></div><div class="drone-image">${icon('drone')}</div><div class="row-foot"><span>${esc(drone.mission)}</span><strong>${drone.battery}%</strong></div><div class="level-track"><i style="width:${drone.battery}%"></i></div></article>`).join('')}</div></section>`;$('#newMission').onclick=()=>toast('Planejador de missão aberto para demonstração.')
}
function renderAlerts(){
  $('#pageRoot').innerHTML=`<section class="screen">${subHeader('Notificações')}<div class="notice-list">${state.notifications.map(item=>`<article class="card notice-row"><span class="notice-bubble">${icon(item.type==='animal'?'cow':item.type==='success'?'leaf':'bell')}</span><div><strong>${esc(item.title)}</strong><small>${esc(item.message)} · ${ago(item.created_at)}</small></div></article>`).join('')}</div></section>`;
}

function openQuickMenu(){openModal('AÇÃO RÁPIDA','O que deseja fazer?',`<div class="quick-menu"><button id="quickPost"><span>${icon('leaf')}</span><div><strong>Nova publicação</strong><small>Compartilhar no feed</small></div>${icon('chevron')}</button><button id="quickAnimal"><span>${icon('cow')}</span><div><strong>Cadastrar animal</strong><small>Adicionar ao rebanho</small></div>${icon('chevron')}</button><button id="quickNfc"><span>${icon('nfc')}</span><div><strong>Ler etiqueta NFC</strong><small>Identificar um animal</small></div>${icon('chevron')}</button><button id="quickWater"><span>${icon('drop')}</span><div><strong>Registrar consumo</strong><small>Adicionar leitura de água</small></div>${icon('chevron')}</button></div>`);$('#quickPost').onclick=()=>swapModal(openPostForm);$('#quickAnimal').onclick=()=>swapModal(()=>openAnimalForm());$('#quickNfc').onclick=()=>swapModal(openNfc);$('#quickWater').onclick=()=>swapModal(openWaterForm)}
function openPostForm(){openModal('NOVA PUBLICAÇÃO','Compartilhar conquista',`<form id="postForm" class="modal-form"><label class="full">Categoria<select name="category"><option>Economia de água</option><option>Rebanho</option><option>Tecnologia</option><option>Conquista</option></select></label><label class="full">O que aconteceu?<textarea name="content" maxlength="500" placeholder="Conte uma novidade da fazenda..." required></textarea></label><div class="form-error full"></div><button class="main-button orange-button full" type="submit">Publicar</button></form>`);$('#postForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;try{await request('/api/posts',{method:'POST',body:Object.fromEntries(new FormData(form))});state.social=await request('/api/social');closeModal();renderCommunity();toast('Publicado na comunidade.')}catch(err){$('.form-error',form).textContent=err.message}}}
function openAnimalForm(tag=''){openModal('NOVO CADASTRO','Adicionar animal',`<form id="animalForm" class="modal-form"><label>Etiqueta NFC<input name="tag" value="${esc(tag)}" placeholder="AG-0001" required></label><label>Nome<input name="name" placeholder="Estrela" required></label><label>Espécie<select name="species"><option>Bovino</option><option>Equino</option><option>Ovino</option><option>Caprino</option></select></label><label>Raça<input name="breed" placeholder="Nelore"></label><label>Setor<input name="sector" placeholder="Pasto Sul" required></label><label>Peso (kg)<input name="weight" type="number" min="0"></label><label class="full">Situação<select name="status"><option>Saudável</option><option>Observação</option><option>Tratamento</option></select></label><div class="form-error full"></div><button class="main-button orange-button full" type="submit">Salvar animal</button></form>`);$('#animalForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;try{await request('/api/animals',{method:'POST',body:Object.fromEntries(new FormData(form))});state.animals=await request('/api/animals');state.dashboard=await request('/api/dashboard');closeModal();renderAnimals();toast('Animal cadastrado.')}catch(err){$('.form-error',form).textContent=err.message}}}
function openWaterForm(){openModal('NOVA LEITURA','Registrar consumo',`<form id="waterForm" class="modal-form"><label class="full">Setor<input name="sector" placeholder="Irrigação do cacau" required></label><label class="full">Litros utilizados<input name="liters" type="number" min="1" placeholder="680" required></label><div class="form-error full"></div><button class="main-button orange-button full" type="submit">Salvar leitura</button></form>`);$('#waterForm').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;try{await request('/api/water',{method:'POST',body:Object.fromEntries(new FormData(form))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Consumo registrado.')}catch(err){$('.form-error',form).textContent=err.message}}}
function openReservoirForm(id,level){openModal('RESERVATÓRIO','Atualizar nível',`<form id="reservoirForm" class="modal-form"><label class="full">Nível: <b id="rangeValue">${level}%</b><input name="level" type="range" min="0" max="100" value="${level}"></label><button class="main-button orange-button full" type="submit">Atualizar</button></form>`);$('[name=level]').oninput=e=>$('#rangeValue').textContent=e.target.value+'%';$('#reservoirForm').onsubmit=async e=>{e.preventDefault();await request(`/api/reservoirs/${id}`,{method:'PATCH',body:Object.fromEntries(new FormData(e.currentTarget))});state.water=await request('/api/water');state.dashboard=await request('/api/dashboard');closeModal();renderWater();toast('Nível atualizado.')}}
async function openNfc(){openModal('IDENTIFICAÇÃO NFC','Aproxime a etiqueta',`<div style="text-align:center"><div class="nfc-rings"><i></i><i></i>${icon('nfc')}</div><p id="nfcStatus" style="font-size:10px;color:var(--muted)">Encoste o celular no brinco NFC do animal.</p><button id="simulateNfc" class="main-button orange-button">Simular leitura</button></div>`);$('#simulateNfc').onclick=()=>{const tag=`AG-${Math.floor(Math.random()*9000+1000)}`;closeModal();openAnimalForm(tag)};if('NDEFReader'in window)try{const reader=new NDEFReader();await reader.scan();$('#nfcStatus').textContent='Leitor ativo. Aproxime a etiqueta.';reader.onreading=event=>{closeModal();openAnimalForm(event.serialNumber||'NFC-LIDO')}}catch{$('#nfcStatus').textContent='Use a simulação abaixo neste dispositivo.'}}
async function updateChallenge(id,value){try{await request(`/api/challenges/${id}`,{method:'PATCH',body:{progress:Number(value)}});state.social=await request('/api/social');renderChallenges();toast('Progresso atualizado.')}catch(e){toast(e.message,true)}}
async function logout(){await request('/api/auth/logout',{method:'POST'});state.user=null;state.farm=null;showOnly('authView');toast('Sessão encerrada.')}

function openModal(label,title,body){$('#modalLabel').textContent=label;$('#modalTitle').textContent=title;$('#modalBody').innerHTML=body;$('#appModal').showModal()}
function closeModal(){if($('#appModal').open)$('#appModal').close()}
function swapModal(callback){closeModal();setTimeout(callback,120)}
$$('[data-close]').forEach(button=>button.onclick=closeModal);$('#appModal').onclick=e=>{if(e.target===$('#appModal'))closeModal()};
function ago(value){const diff=Date.now()-new Date(String(value).replace(' ','T')+'Z').getTime();const hours=Math.max(1,Math.floor(diff/36e5));return hours<24?`${hours} h`:`${Math.floor(hours/24)} d`}
function weekday(value){return new Intl.DateTimeFormat('pt-BR',{weekday:'short'}).format(new Date(value+'T12:00:00')).replace('.','')}

boot();
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
