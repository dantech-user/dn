# Hydra Agro

Aplicativo mobile de gestão rural com feed, desafios, ranking sustentável, identificação NFC, animais, água, drones e alertas.

O design 3.0 reproduz as prévias aprovadas: splash verde, login com paisagem, início com resumo diário, feed da comunidade, desafios, ranking e perfil da Fazenda Boa Vista. A interface é mobile tanto no navegador quanto no APK.

## Abrir no GitHub Codespaces

1. Envie todos os arquivos para um repositório do GitHub.
2. Abra **Code → Codespaces → Create codespace on main**.
3. Aguarde o Codespaces executar `npm install` e `npm start`.
4. Abra a aba **Ports** e clique no endereço da porta `4173`.

Para iniciar manualmente:

```bash
npm start
```

## Banco de dados

### Demonstração no Codespaces

O aplicativo cria automaticamente `data/hydra-agro.sqlite`. Cadastro, login, fazenda, animais, água, publicações e desafios já funcionam sem serviço externo.

### Aplicativo publicado

O banco de produção planejado é Supabase/PostgreSQL:

- Supabase Auth para cadastro e login;
- PostgreSQL para fazendas, animais, água, drones, feed e desafios;
- Storage para fotos;
- Row Level Security para cada proprietário acessar somente os dados permitidos;
- Realtime para atualizações e alertas instantâneos.

O esquema completo está em `supabase/schema.sql`. Crie um projeto Supabase, abra o **SQL Editor** e execute esse arquivo uma vez. Depois, use `.env.example` como referência para configurar as chaves.

## Gerar APK Android

O projeto inclui Capacitor e o workflow `.github/workflows/android-apk.yml`.

1. Publique o servidor Hydra Agro em um endereço HTTPS.
2. No repositório, abra **Settings → Secrets and variables → Actions**.
3. Crie o secret `HYDRA_APP_URL` com o endereço publicado completo.
4. Abra **Actions → Gerar APK Hydra Agro → Run workflow**.
5. Ao terminar, baixe o arquivo `hydra-agro-apk` em **Artifacts**.

O workflow também gera automaticamente o ícone do Hydra Agro e a splash nativa do Android a partir dos arquivos em `assets/`.

O Android gerado pelo Capacitor suporta Android 7 ou superior.

## Testes

```bash
npm test
```
